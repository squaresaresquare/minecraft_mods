package net.minecraft;

import net.fabricmc.api.ClientModInitializer;
import org.squaresaresquare.client.block.ModBlocks;
import org.squaresaresquare.client.block.entity.ModBlockEntities;
import org.squaresaresquare.client.creativemodetab.ModCreativeModeTabs;

public class Client implements ClientModInitializer  {
    public static final String MOD_ID = "blocks";
    @Override
    public void onInitializeClient() {
        ModBlocks.initialize();
        ModCreativeModeTabs.registerModCreativeModeTabs();
        ModBlockEntities.initialize();
    }
}

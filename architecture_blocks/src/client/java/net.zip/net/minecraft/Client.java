package net.minecraft;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockColorRegistry;
import net.minecraft.client.color.block.BlockTintSource;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.block.ModBlocks;
import java.util.List;
import net.minecraft.block.custom.OakLogBlock;

public class Client implements ClientModInitializer  {
    public static final String MOD_ID = "blocks";
    @Override
    public void onInitializeClient() {
        /*BlockColorRegistry.register(List.of(new BlockTintSource() {
            @Override
            public int colorInWorld(BlockState state, BlockAndTintGetter level, BlockPos pos) {
                // Read from the blockstate safely, no infinite loops!
                if (state.getValue(OakLogBlock.ON_GRASS)) {
                    return 0xFF98FB98;
                }
                return 0xFFFFDAB9;
            }
            @Override
            public int color(BlockState state) {
                return 0xFFFFDAB9;
            }
        }), ModBlocks.OAK_LOG);*/
    }
}

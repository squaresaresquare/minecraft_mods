package net.minecraft.rendering.blockentity;

import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Display;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class OakLogEntityRenderState extends BlockEntityRenderState {
    public BlockPos lightPosition;
    public float rotation;
    final Display.ItemDisplay.ItemRenderState itemRenderState = new Display.ItemDisplay.ItemRenderState(ItemStack.EMPTY, ItemDisplayContext.NONE);
}

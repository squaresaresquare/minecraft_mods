package org.seanpaulhumphrey.architecture.world;

import org.seanpaulhumphrey.architecture.Architecture;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.gen.placementmodifier.*;

import java.util.List;

public class ModPlacedFeatures {
    public static final class_5321<class_6796> TRIPLE_WINDOW_TOP_ARCH_1_1_KEY = registerKey("triple_window_top_arch_1_1");
    public static final class_5321<class_6796> TRIPLE_WINDOW_LEFT_BOTTOM_KEY = registerKey("triple_window_left_bottom");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_2_2_KEY = registerKey("quad_window_top_arch_2_2");
    public static final class_5321<class_6796> TRIPLE_WINDOW_MIDDLE_LEFT_KEY = registerKey("triple_window_middle_left");
    public static final class_5321<class_6796> THIN_QUARTZ_BASE_KEY = registerKey("thin_quartz_base");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_1_6_KEY = registerKey("quad_window_top_arch_1_6");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_2_3_KEY = registerKey("quad_window_top_arch_2_3");
    public static final class_5321<class_6796> TWIN_COLUMN_CAPITAL_KEY = registerKey("twin_column_capital");
    public static final class_5321<class_6796> TRIPLE_WINDOW_CAP_LEFT_KEY = registerKey("triple_window_cap_left");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_2_4_KEY = registerKey("quad_window_top_arch_2_4");
    public static final class_5321<class_6796> TRIPLE_WINDOW_TOP_CAP_MIDDLE_KEY = registerKey("triple_window_top_cap_middle");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_1_1_KEY = registerKey("quad_window_top_arch_1_1");
    public static final class_5321<class_6796> TRIPLE_WINDOW_TOP_ARCH_MIDDLE_KEY = registerKey("triple_window_top_arch_middle");
    public static final class_5321<class_6796> TRIPLE_WINDOW_MIDDLE_BOTTOM_KEY = registerKey("triple_window_middle_bottom");
    public static final class_5321<class_6796> TRIPLE_WINDOW_RIGHT_BOTTOM_KEY = registerKey("triple_window_right_bottom");
    public static final class_5321<class_6796> TRIPLE_WINDOW_TOP_ARCH_2_2_KEY = registerKey("triple_window_top_arch_2_2");
    public static final class_5321<class_6796> TRIPLE_WINDOW_TOP_ARCH_LEFT_KEY = registerKey("triple_window_top_arch_left");
    public static final class_5321<class_6796> THIN_QUARTZ_COLUMN_KEY = registerKey("thin_quartz_column");
    public static final class_5321<class_6796> TRIPLE_WINDOW_TOP_ARCH_2_3_KEY = registerKey("triple_window_top_arch_2_3");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_2_5_KEY = registerKey("quad_window_top_arch_2_5");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_1_3_KEY = registerKey("quad_window_top_arch_1_3");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_2_6_KEY = registerKey("quad_window_top_arch_2_6");
    public static final class_5321<class_6796> TWIN_COLUMNS_KEY = registerKey("twin_columns");
    public static final class_5321<class_6796> QUARTZ_PILLAR_KEY = registerKey("quartz_pillar");
    public static final class_5321<class_6796> HALF_QUARTZ_PILLAR_KEY = registerKey("half_quartz_pillar");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_1_2_KEY = registerKey("quad_window_top_arch_1_2");
    public static final class_5321<class_6796> TWIN_COLUMN_BASE_KEY = registerKey("twin_column_base");
    public static final class_5321<class_6796> TRIPLE_WINDOW_TOP_ARCH_1_3_KEY = registerKey("triple_window_top_arch_1_3");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_1_5_KEY = registerKey("quad_window_top_arch_1_5");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_2_1_KEY = registerKey("quad_window_top_arch_2_1");
    public static final class_5321<class_6796> QUAD_WINDOW_TOP_ARCH_1_4_KEY = registerKey("quad_window_top_arch_1_4");
    public static final class_5321<class_6796> TRIPLE_WINDOW_MIDDLE_MIDDLE_KEY = registerKey("triple_window_middle_middle");
    public static final class_5321<class_6796> THIN_QUARTZ_CAPITAL_KEY = registerKey("thin_quartz_capital");
    public static final class_5321<class_6796> TRIPLE_WINDOW_TOP_CAP_RIGHT_KEY = registerKey("triple_window_top_cap_right");
    public static final class_5321<class_6796> TRIPLE_WINDOW_TOP_ARCH_1_2_KEY = registerKey("triple_window_top_arch_1_2");
    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatures = context.method_46799(class_7924.field_41239);
    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(Architecture.MOD_ID, name));
    }

    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                                                                   class_6880<class_2975<?, ?>> configuration,
                                                                                   class_6797... modifiers) {
        register(context, key, configuration, List.of(modifiers));
    }
}


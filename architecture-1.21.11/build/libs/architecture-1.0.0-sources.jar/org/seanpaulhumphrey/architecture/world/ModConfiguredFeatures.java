package org.seanpaulhumphrey.architecture.world;

import org.seanpaulhumphrey.architecture.Architecture;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;

public class ModConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_TOP_ARCH_1_1 = registerKey("triple_window_top_arch_1_1");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_LEFT_BOTTOM = registerKey("triple_window_left_bottom");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_2_2 = registerKey("quad_window_top_arch_2_2");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_MIDDLE_LEFT = registerKey("triple_window_middle_left");

    public static final class_5321<class_2975<?, ?>> THIN_QUARTZ_BASE = registerKey("thin_quartz_base");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_1_6 = registerKey("quad_window_top_arch_1_6");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_2_3 = registerKey("quad_window_top_arch_2_3");

    public static final class_5321<class_2975<?, ?>> TWIN_COLUMN_CAPITAL = registerKey("twin_column_capital");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_CAP_LEFT = registerKey("triple_window_cap_left");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_2_4 = registerKey("quad_window_top_arch_2_4");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_TOP_CAP_MIDDLE = registerKey("triple_window_top_cap_middle");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_1_1 = registerKey("quad_window_top_arch_1_1");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_TOP_ARCH_MIDDLE = registerKey("triple_window_top_arch_middle");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_MIDDLE_BOTTOM = registerKey("triple_window_middle_bottom");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_RIGHT_BOTTOM = registerKey("triple_window_right_bottom");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_TOP_ARCH_2_2 = registerKey("triple_window_top_arch_2_2");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_TOP_ARCH_LEFT = registerKey("triple_window_top_arch_left");

    public static final class_5321<class_2975<?, ?>> THIN_QUARTZ_COLUMN = registerKey("thin_quartz_column");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_TOP_ARCH_2_3 = registerKey("triple_window_top_arch_2_3");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_2_5 = registerKey("quad_window_top_arch_2_5");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_1_3 = registerKey("quad_window_top_arch_1_3");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_2_6 = registerKey("quad_window_top_arch_2_6");

    public static final class_5321<class_2975<?, ?>> TWIN_COLUMNS = registerKey("twin_columns");

    public static final class_5321<class_2975<?, ?>> QUARTZ_PILLAR = registerKey("quartz_pillar");

    public static final class_5321<class_2975<?, ?>> HALF_QUARTZ_PILLAR = registerKey("half_quartz_pillar");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_1_2 = registerKey("quad_window_top_arch_1_2");

    public static final class_5321<class_2975<?, ?>> TWIN_COLUMN_BASE = registerKey("twin_column_base");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_TOP_ARCH_1_3 = registerKey("triple_window_top_arch_1_3");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_1_5 = registerKey("quad_window_top_arch_1_5");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_2_1 = registerKey("quad_window_top_arch_2_1");

    public static final class_5321<class_2975<?, ?>> QUAD_WINDOW_TOP_ARCH_1_4 = registerKey("quad_window_top_arch_1_4");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_MIDDLE_MIDDLE = registerKey("triple_window_middle_middle");

    public static final class_5321<class_2975<?, ?>> THIN_QUARTZ_CAPITAL = registerKey("thin_quartz_capital");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_TOP_CAP_RIGHT = registerKey("triple_window_top_cap_right");

    public static final class_5321<class_2975<?, ?>> TRIPLE_WINDOW_TOP_ARCH_1_2 = registerKey("triple_window_top_arch_1_2");

    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_60655(Architecture.MOD_ID, name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }
}


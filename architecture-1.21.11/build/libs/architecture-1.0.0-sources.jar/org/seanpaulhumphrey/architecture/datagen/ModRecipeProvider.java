package org.seanpaulhumphrey.architecture.datagen;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import org.seanpaulhumphrey.architecture.block.ModBlocks;
import org.seanpaulhumphrey.architecture.item.ModItems;
import java.util.concurrent.CompletableFuture;

public class ModRecipeProvider extends FabricRecipeProvider {
    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 recipeExporter) {
        return new class_2446(wrapperLookup, recipeExporter) {
            @Override
            public void method_10419() {
                method_36325(class_7800.field_40634, ModBlocks.HALF_QUARTZ_PILLAR, class_7800.field_40635, ModBlocks.HALF_QUARTZ_PILLAR);

                method_62746(class_7800.field_40642, ModBlocks.HALF_QUARTZ_PILLAR)
                        .method_10439("XXX")
                        .method_10439("XQX")
                        .method_10439("XXX")
                        .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
                        .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
                        .method_10431(field_53721);

                method_62750(class_7800.field_40642, ModBlocks.QUARTZ_PILLAR, 9)
                        .method_10454(ModBlocks.QUARTZ_PILLAR)
                        .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
                        .method_10431(field_53721);

                    method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_1, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_1);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_1)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_1, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_LEFT_BOTTOM, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_LEFT_BOTTOM);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_LEFT_BOTTOM)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_LEFT_BOTTOM, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_2, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_2);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_2)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_2, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_MIDDLE_LEFT, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_MIDDLE_LEFT);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_MIDDLE_LEFT)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_MIDDLE_LEFT, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.THIN_QUARTZ_BASE, class_7800.field_40635, ModBlocks.THIN_QUARTZ_BASE);
    method_62746(class_7800.field_40642, ModBlocks.THIN_QUARTZ_BASE)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.THIN_QUARTZ_BASE, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_6, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_6);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_6)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_6, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_3, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_3);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_3)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_3, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TWIN_COLUMN_CAPITAL, class_7800.field_40635, ModBlocks.TWIN_COLUMN_CAPITAL);
    method_62746(class_7800.field_40642, ModBlocks.TWIN_COLUMN_CAPITAL)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TWIN_COLUMN_CAPITAL, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_CAP_LEFT, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_CAP_LEFT);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_CAP_LEFT)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_CAP_LEFT, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_4, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_4);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_4)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_4, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_TOP_CAP_MIDDLE, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_TOP_CAP_MIDDLE);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_CAP_MIDDLE)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_CAP_MIDDLE, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_1, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_1);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_1)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_1, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_MIDDLE, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_MIDDLE);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_MIDDLE)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_MIDDLE, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_MIDDLE_BOTTOM, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_MIDDLE_BOTTOM);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_MIDDLE_BOTTOM)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_MIDDLE_BOTTOM, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_RIGHT_BOTTOM, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_RIGHT_BOTTOM);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_RIGHT_BOTTOM)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_RIGHT_BOTTOM, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_2, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_2);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_2)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_2, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_LEFT, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_LEFT);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_LEFT)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_LEFT, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.THIN_QUARTZ_COLUMN, class_7800.field_40635, ModBlocks.THIN_QUARTZ_COLUMN);
    method_62746(class_7800.field_40642, ModBlocks.THIN_QUARTZ_COLUMN)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.THIN_QUARTZ_COLUMN, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_3, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_3);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_3)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_3, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_5, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_5);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_5)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_5, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_3, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_3);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_3)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_3, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_6, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_6);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_6)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_6, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TWIN_COLUMNS, class_7800.field_40635, ModBlocks.TWIN_COLUMNS);
    method_62746(class_7800.field_40642, ModBlocks.TWIN_COLUMNS)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TWIN_COLUMNS, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUARTZ_PILLAR, class_7800.field_40635, ModBlocks.QUARTZ_PILLAR);
    method_62746(class_7800.field_40642, ModBlocks.QUARTZ_PILLAR)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUARTZ_PILLAR, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.HALF_QUARTZ_PILLAR, class_7800.field_40635, ModBlocks.HALF_QUARTZ_PILLAR);
    method_62746(class_7800.field_40642, ModBlocks.HALF_QUARTZ_PILLAR)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.HALF_QUARTZ_PILLAR, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_2, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_2);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_2)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_2, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TWIN_COLUMN_BASE, class_7800.field_40635, ModBlocks.TWIN_COLUMN_BASE);
    method_62746(class_7800.field_40642, ModBlocks.TWIN_COLUMN_BASE)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TWIN_COLUMN_BASE, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_3, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_3);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_3)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_3, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_5, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_5);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_5)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_5, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_1, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_1);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_1)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_2_1, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_4, class_7800.field_40635, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_4);
    method_62746(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_4)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.QUAD_WINDOW_TOP_ARCH_1_4, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_MIDDLE_MIDDLE, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_MIDDLE_MIDDLE);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_MIDDLE_MIDDLE)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_MIDDLE_MIDDLE, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.THIN_QUARTZ_CAPITAL, class_7800.field_40635, ModBlocks.THIN_QUARTZ_CAPITAL);
    method_62746(class_7800.field_40642, ModBlocks.THIN_QUARTZ_CAPITAL)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.THIN_QUARTZ_CAPITAL, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_TOP_CAP_RIGHT, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_TOP_CAP_RIGHT);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_CAP_RIGHT)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_CAP_RIGHT, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    
                method_36325(class_7800.field_40634, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_2, class_7800.field_40635, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_2);
    method_62746(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_2)
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10439("XXX")
            .method_10434('Q', ModBlocks.QUARTZ_PILLAR)
            .method_10429(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);

    method_62750(class_7800.field_40642, ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_2, 9)
            .method_10454(ModBlocks.QUARTZ_PILLAR)
            .method_10442(method_32807(ModBlocks.QUARTZ_PILLAR), method_10426(ModBlocks.QUARTZ_PILLAR))
            .method_10431(field_53721);
    

            }
        };
    }

    @Override
    public String method_10321() {
        return "Architecture Recipes";
    }
}

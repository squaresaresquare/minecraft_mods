package org.seanpaulhumphrey.architecture.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_1887;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import org.seanpaulhumphrey.architecture.block.ModBlocks;
import java.util.concurrent.CompletableFuture;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {
        class_7225.class_7226<class_1887> impl = this.field_51845.method_46762(class_7924.field_41265);

        method_46025(ModBlocks.QUARTZ_PILLAR);
        method_46025(ModBlocks.HALF_QUARTZ_PILLAR);
                method_46025(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_1);

        method_46025(ModBlocks.TRIPLE_WINDOW_LEFT_BOTTOM);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_2);

        method_46025(ModBlocks.TRIPLE_WINDOW_MIDDLE_LEFT);

        method_46025(ModBlocks.THIN_QUARTZ_BASE);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_6);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_3);

        method_46025(ModBlocks.TWIN_COLUMN_CAPITAL);

        method_46025(ModBlocks.TRIPLE_WINDOW_CAP_LEFT);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_4);

        method_46025(ModBlocks.TRIPLE_WINDOW_TOP_CAP_MIDDLE);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_1);

        method_46025(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_MIDDLE);

        method_46025(ModBlocks.TRIPLE_WINDOW_MIDDLE_BOTTOM);

        method_46025(ModBlocks.TRIPLE_WINDOW_RIGHT_BOTTOM);

        method_46025(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_2);

        method_46025(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_LEFT);

        method_46025(ModBlocks.THIN_QUARTZ_COLUMN);

        method_46025(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_3);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_5);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_3);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_6);

        method_46025(ModBlocks.TWIN_COLUMNS);

        method_46025(ModBlocks.QUARTZ_PILLAR);

        method_46025(ModBlocks.HALF_QUARTZ_PILLAR);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_2);

        method_46025(ModBlocks.TWIN_COLUMN_BASE);

        method_46025(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_3);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_5);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_1);

        method_46025(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_4);

        method_46025(ModBlocks.TRIPLE_WINDOW_MIDDLE_MIDDLE);

        method_46025(ModBlocks.THIN_QUARTZ_CAPITAL);

        method_46025(ModBlocks.TRIPLE_WINDOW_TOP_CAP_RIGHT);

        method_46025(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_2);

    }
}


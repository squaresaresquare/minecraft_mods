package org.seanpaulhumphrey.architecture.recipe;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_10355;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_314;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9887;
import net.minecraft.recipe.*;

public record ThinQuartzCapitalRecipe(class_1856 inputItem, class_1799 output) implements class_1860<ThinQuartzCapitalRecipeInput> {
    public class_2371<class_1856> getIngredients() {
        class_2371<class_1856> list = class_2371.method_10211();
        list.add(this.inputItem);
        return list;
    }

    // read Recipe JSON files --> new ThinQuartzCapitalRecipe

    @Override
    public boolean matches(ThinQuartzCapitalRecipeInput input, class_1937 world) {
        if(world.method_8608()) {
            return false;
        }

        return inputItem.method_8093(input.method_59984(0));
    }

    @Override
    public class_1799 craft(ThinQuartzCapitalRecipeInput input, class_7225.class_7874 lookup) {
        return output.method_7972();
    }

    @Override
    public class_1865<? extends class_1860<ThinQuartzCapitalRecipeInput>> method_8119() {
        return ModRecipes.THIN_QUARTZ_CAPITAL_SERIALIZER;
    }

    @Override
    public class_3956<? extends class_1860<ThinQuartzCapitalRecipeInput>> method_17716() {
        return ModRecipes.THIN_QUARTZ_CAPITAL_TYPE;
    }

    @Override
    public class_9887 method_61671() {
        return class_9887.method_61682(inputItem);
    }

    @Override
    public class_10355 method_64668() {
        return class_314.field_1810;
    }

    public static class Serializer implements class_1865<ThinQuartzCapitalRecipe> {
        public static final MapCodec<ThinQuartzCapitalRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                class_1856.field_46095.fieldOf("ingredient").forGetter(ThinQuartzCapitalRecipe::inputItem),
                class_1799.field_24671.fieldOf("result").forGetter(ThinQuartzCapitalRecipe::output)
        ).apply(inst, ThinQuartzCapitalRecipe::new));

        public static final class_9139<class_9129, ThinQuartzCapitalRecipe> STREAM_CODEC =
                class_9139.method_56435(
                        class_1856.field_48355, ThinQuartzCapitalRecipe::inputItem,
                        class_1799.field_48349, ThinQuartzCapitalRecipe::output,
                        ThinQuartzCapitalRecipe::new);

        @Override
        public MapCodec<ThinQuartzCapitalRecipe> method_53736() {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, ThinQuartzCapitalRecipe> method_56104() {
            return STREAM_CODEC;
        }
    }
}
    
package org.seanpaulhumphrey.architecture.recipe;

import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;
import org.seanpaulhumphrey.architecture.*;

public class ModRecipes {
public static final class_1865<TripleWindowTopArch11Recipe> TRIPLE_WINDOW_TOP_ARCH_1_1_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_1_1"),
        new TripleWindowTopArch11Recipe.Serializer());
    public static final class_3956<TripleWindowTopArch11Recipe> TRIPLE_WINDOW_TOP_ARCH_1_1_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_1_1"), new class_3956<TripleWindowTopArch11Recipe>() {
            @Override
            public String toString() {
                return "triple_window_top_arch_1_1";
            }
        });
    

public static final class_1865<TripleWindowLeftBottomRecipe> TRIPLE_WINDOW_LEFT_BOTTOM_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_left_bottom"),
        new TripleWindowLeftBottomRecipe.Serializer());
    public static final class_3956<TripleWindowLeftBottomRecipe> TRIPLE_WINDOW_LEFT_BOTTOM_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_left_bottom"), new class_3956<TripleWindowLeftBottomRecipe>() {
            @Override
            public String toString() {
                return "triple_window_left_bottom";
            }
        });
    

public static final class_1865<QuadWindowTopArch22Recipe> QUAD_WINDOW_TOP_ARCH_2_2_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_2"),
        new QuadWindowTopArch22Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch22Recipe> QUAD_WINDOW_TOP_ARCH_2_2_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_2"), new class_3956<QuadWindowTopArch22Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_2_2";
            }
        });
    

public static final class_1865<TripleWindowMiddleLeftRecipe> TRIPLE_WINDOW_MIDDLE_LEFT_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_middle_left"),
        new TripleWindowMiddleLeftRecipe.Serializer());
    public static final class_3956<TripleWindowMiddleLeftRecipe> TRIPLE_WINDOW_MIDDLE_LEFT_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_middle_left"), new class_3956<TripleWindowMiddleLeftRecipe>() {
            @Override
            public String toString() {
                return "triple_window_middle_left";
            }
        });
    

public static final class_1865<ThinQuartzBaseRecipe> THIN_QUARTZ_BASE_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "thin_quartz_base"),
        new ThinQuartzBaseRecipe.Serializer());
    public static final class_3956<ThinQuartzBaseRecipe> THIN_QUARTZ_BASE_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "thin_quartz_base"), new class_3956<ThinQuartzBaseRecipe>() {
            @Override
            public String toString() {
                return "thin_quartz_base";
            }
        });
    

public static final class_1865<QuadWindowTopArch16Recipe> QUAD_WINDOW_TOP_ARCH_1_6_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_6"),
        new QuadWindowTopArch16Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch16Recipe> QUAD_WINDOW_TOP_ARCH_1_6_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_6"), new class_3956<QuadWindowTopArch16Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_1_6";
            }
        });
    

public static final class_1865<QuadWindowTopArch23Recipe> QUAD_WINDOW_TOP_ARCH_2_3_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_3"),
        new QuadWindowTopArch23Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch23Recipe> QUAD_WINDOW_TOP_ARCH_2_3_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_3"), new class_3956<QuadWindowTopArch23Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_2_3";
            }
        });
    

public static final class_1865<TwinColumnCapitalRecipe> TWIN_COLUMN_CAPITAL_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "twin_column_capital"),
        new TwinColumnCapitalRecipe.Serializer());
    public static final class_3956<TwinColumnCapitalRecipe> TWIN_COLUMN_CAPITAL_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "twin_column_capital"), new class_3956<TwinColumnCapitalRecipe>() {
            @Override
            public String toString() {
                return "twin_column_capital";
            }
        });
    

public static final class_1865<TripleWindowCapLeftRecipe> TRIPLE_WINDOW_CAP_LEFT_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_cap_left"),
        new TripleWindowCapLeftRecipe.Serializer());
    public static final class_3956<TripleWindowCapLeftRecipe> TRIPLE_WINDOW_CAP_LEFT_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_cap_left"), new class_3956<TripleWindowCapLeftRecipe>() {
            @Override
            public String toString() {
                return "triple_window_cap_left";
            }
        });
    

public static final class_1865<QuadWindowTopArch24Recipe> QUAD_WINDOW_TOP_ARCH_2_4_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_4"),
        new QuadWindowTopArch24Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch24Recipe> QUAD_WINDOW_TOP_ARCH_2_4_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_4"), new class_3956<QuadWindowTopArch24Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_2_4";
            }
        });
    

public static final class_1865<TripleWindowTopCapMiddleRecipe> TRIPLE_WINDOW_TOP_CAP_MIDDLE_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_cap_middle"),
        new TripleWindowTopCapMiddleRecipe.Serializer());
    public static final class_3956<TripleWindowTopCapMiddleRecipe> TRIPLE_WINDOW_TOP_CAP_MIDDLE_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_cap_middle"), new class_3956<TripleWindowTopCapMiddleRecipe>() {
            @Override
            public String toString() {
                return "triple_window_top_cap_middle";
            }
        });
    

public static final class_1865<QuadWindowTopArch11Recipe> QUAD_WINDOW_TOP_ARCH_1_1_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_1"),
        new QuadWindowTopArch11Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch11Recipe> QUAD_WINDOW_TOP_ARCH_1_1_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_1"), new class_3956<QuadWindowTopArch11Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_1_1";
            }
        });
    

public static final class_1865<TripleWindowTopArchMiddleRecipe> TRIPLE_WINDOW_TOP_ARCH_MIDDLE_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_middle"),
        new TripleWindowTopArchMiddleRecipe.Serializer());
    public static final class_3956<TripleWindowTopArchMiddleRecipe> TRIPLE_WINDOW_TOP_ARCH_MIDDLE_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_middle"), new class_3956<TripleWindowTopArchMiddleRecipe>() {
            @Override
            public String toString() {
                return "triple_window_top_arch_middle";
            }
        });
    

public static final class_1865<TripleWindowMiddleBottomRecipe> TRIPLE_WINDOW_MIDDLE_BOTTOM_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_middle_bottom"),
        new TripleWindowMiddleBottomRecipe.Serializer());
    public static final class_3956<TripleWindowMiddleBottomRecipe> TRIPLE_WINDOW_MIDDLE_BOTTOM_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_middle_bottom"), new class_3956<TripleWindowMiddleBottomRecipe>() {
            @Override
            public String toString() {
                return "triple_window_middle_bottom";
            }
        });
    

public static final class_1865<TripleWindowRightBottomRecipe> TRIPLE_WINDOW_RIGHT_BOTTOM_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_right_bottom"),
        new TripleWindowRightBottomRecipe.Serializer());
    public static final class_3956<TripleWindowRightBottomRecipe> TRIPLE_WINDOW_RIGHT_BOTTOM_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_right_bottom"), new class_3956<TripleWindowRightBottomRecipe>() {
            @Override
            public String toString() {
                return "triple_window_right_bottom";
            }
        });
    

public static final class_1865<TripleWindowTopArch22Recipe> TRIPLE_WINDOW_TOP_ARCH_2_2_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_2_2"),
        new TripleWindowTopArch22Recipe.Serializer());
    public static final class_3956<TripleWindowTopArch22Recipe> TRIPLE_WINDOW_TOP_ARCH_2_2_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_2_2"), new class_3956<TripleWindowTopArch22Recipe>() {
            @Override
            public String toString() {
                return "triple_window_top_arch_2_2";
            }
        });
    

public static final class_1865<TripleWindowTopArchLeftRecipe> TRIPLE_WINDOW_TOP_ARCH_LEFT_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_left"),
        new TripleWindowTopArchLeftRecipe.Serializer());
    public static final class_3956<TripleWindowTopArchLeftRecipe> TRIPLE_WINDOW_TOP_ARCH_LEFT_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_left"), new class_3956<TripleWindowTopArchLeftRecipe>() {
            @Override
            public String toString() {
                return "triple_window_top_arch_left";
            }
        });
    

public static final class_1865<ThinQuartzColumnRecipe> THIN_QUARTZ_COLUMN_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "thin_quartz_column"),
        new ThinQuartzColumnRecipe.Serializer());
    public static final class_3956<ThinQuartzColumnRecipe> THIN_QUARTZ_COLUMN_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "thin_quartz_column"), new class_3956<ThinQuartzColumnRecipe>() {
            @Override
            public String toString() {
                return "thin_quartz_column";
            }
        });
    

public static final class_1865<TripleWindowTopArch23Recipe> TRIPLE_WINDOW_TOP_ARCH_2_3_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_2_3"),
        new TripleWindowTopArch23Recipe.Serializer());
    public static final class_3956<TripleWindowTopArch23Recipe> TRIPLE_WINDOW_TOP_ARCH_2_3_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_2_3"), new class_3956<TripleWindowTopArch23Recipe>() {
            @Override
            public String toString() {
                return "triple_window_top_arch_2_3";
            }
        });
    

public static final class_1865<QuadWindowTopArch25Recipe> QUAD_WINDOW_TOP_ARCH_2_5_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_5"),
        new QuadWindowTopArch25Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch25Recipe> QUAD_WINDOW_TOP_ARCH_2_5_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_5"), new class_3956<QuadWindowTopArch25Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_2_5";
            }
        });
    

public static final class_1865<QuadWindowTopArch13Recipe> QUAD_WINDOW_TOP_ARCH_1_3_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_3"),
        new QuadWindowTopArch13Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch13Recipe> QUAD_WINDOW_TOP_ARCH_1_3_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_3"), new class_3956<QuadWindowTopArch13Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_1_3";
            }
        });
    

public static final class_1865<QuadWindowTopArch26Recipe> QUAD_WINDOW_TOP_ARCH_2_6_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_6"),
        new QuadWindowTopArch26Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch26Recipe> QUAD_WINDOW_TOP_ARCH_2_6_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_6"), new class_3956<QuadWindowTopArch26Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_2_6";
            }
        });
    

public static final class_1865<TwinColumnsRecipe> TWIN_COLUMNS_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "twin_columns"),
        new TwinColumnsRecipe.Serializer());
    public static final class_3956<TwinColumnsRecipe> TWIN_COLUMNS_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "twin_columns"), new class_3956<TwinColumnsRecipe>() {
            @Override
            public String toString() {
                return "twin_columns";
            }
        });
    

public static final class_1865<QuartzPillarRecipe> QUARTZ_PILLAR_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quartz_pillar"),
        new QuartzPillarRecipe.Serializer());
    public static final class_3956<QuartzPillarRecipe> QUARTZ_PILLAR_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quartz_pillar"), new class_3956<QuartzPillarRecipe>() {
            @Override
            public String toString() {
                return "quartz_pillar";
            }
        });
    

public static final class_1865<HalfQuartzPillarRecipe> HALF_QUARTZ_PILLAR_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "half_quartz_pillar"),
        new HalfQuartzPillarRecipe.Serializer());
    public static final class_3956<HalfQuartzPillarRecipe> HALF_QUARTZ_PILLAR_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "half_quartz_pillar"), new class_3956<HalfQuartzPillarRecipe>() {
            @Override
            public String toString() {
                return "half_quartz_pillar";
            }
        });
    

public static final class_1865<QuadWindowTopArch12Recipe> QUAD_WINDOW_TOP_ARCH_1_2_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_2"),
        new QuadWindowTopArch12Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch12Recipe> QUAD_WINDOW_TOP_ARCH_1_2_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_2"), new class_3956<QuadWindowTopArch12Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_1_2";
            }
        });
    

public static final class_1865<TwinColumnBaseRecipe> TWIN_COLUMN_BASE_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "twin_column_base"),
        new TwinColumnBaseRecipe.Serializer());
    public static final class_3956<TwinColumnBaseRecipe> TWIN_COLUMN_BASE_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "twin_column_base"), new class_3956<TwinColumnBaseRecipe>() {
            @Override
            public String toString() {
                return "twin_column_base";
            }
        });
    

public static final class_1865<TripleWindowTopArch13Recipe> TRIPLE_WINDOW_TOP_ARCH_1_3_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_1_3"),
        new TripleWindowTopArch13Recipe.Serializer());
    public static final class_3956<TripleWindowTopArch13Recipe> TRIPLE_WINDOW_TOP_ARCH_1_3_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_1_3"), new class_3956<TripleWindowTopArch13Recipe>() {
            @Override
            public String toString() {
                return "triple_window_top_arch_1_3";
            }
        });
    

public static final class_1865<QuadWindowTopArch15Recipe> QUAD_WINDOW_TOP_ARCH_1_5_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_5"),
        new QuadWindowTopArch15Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch15Recipe> QUAD_WINDOW_TOP_ARCH_1_5_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_5"), new class_3956<QuadWindowTopArch15Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_1_5";
            }
        });
    

public static final class_1865<QuadWindowTopArch21Recipe> QUAD_WINDOW_TOP_ARCH_2_1_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_1"),
        new QuadWindowTopArch21Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch21Recipe> QUAD_WINDOW_TOP_ARCH_2_1_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_1"), new class_3956<QuadWindowTopArch21Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_2_1";
            }
        });
    

public static final class_1865<QuadWindowTopArch14Recipe> QUAD_WINDOW_TOP_ARCH_1_4_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_4"),
        new QuadWindowTopArch14Recipe.Serializer());
    public static final class_3956<QuadWindowTopArch14Recipe> QUAD_WINDOW_TOP_ARCH_1_4_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_4"), new class_3956<QuadWindowTopArch14Recipe>() {
            @Override
            public String toString() {
                return "quad_window_top_arch_1_4";
            }
        });
    

public static final class_1865<TripleWindowMiddleMiddleRecipe> TRIPLE_WINDOW_MIDDLE_MIDDLE_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_middle_middle"),
        new TripleWindowMiddleMiddleRecipe.Serializer());
    public static final class_3956<TripleWindowMiddleMiddleRecipe> TRIPLE_WINDOW_MIDDLE_MIDDLE_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_middle_middle"), new class_3956<TripleWindowMiddleMiddleRecipe>() {
            @Override
            public String toString() {
                return "triple_window_middle_middle";
            }
        });
    

public static final class_1865<ThinQuartzCapitalRecipe> THIN_QUARTZ_CAPITAL_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "thin_quartz_capital"),
        new ThinQuartzCapitalRecipe.Serializer());
    public static final class_3956<ThinQuartzCapitalRecipe> THIN_QUARTZ_CAPITAL_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "thin_quartz_capital"), new class_3956<ThinQuartzCapitalRecipe>() {
            @Override
            public String toString() {
                return "thin_quartz_capital";
            }
        });
    

public static final class_1865<TripleWindowTopCapRightRecipe> TRIPLE_WINDOW_TOP_CAP_RIGHT_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_cap_right"),
        new TripleWindowTopCapRightRecipe.Serializer());
    public static final class_3956<TripleWindowTopCapRightRecipe> TRIPLE_WINDOW_TOP_CAP_RIGHT_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_cap_right"), new class_3956<TripleWindowTopCapRightRecipe>() {
            @Override
            public String toString() {
                return "triple_window_top_cap_right";
            }
        });
    

public static final class_1865<TripleWindowTopArch12Recipe> TRIPLE_WINDOW_TOP_ARCH_1_2_SERIALIZER = class_2378.method_10230(
    class_7923.field_41189, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_1_2"),
        new TripleWindowTopArch12Recipe.Serializer());
    public static final class_3956<TripleWindowTopArch12Recipe> TRIPLE_WINDOW_TOP_ARCH_1_2_TYPE = class_2378.method_10230(
        class_7923.field_41188, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_1_2"), new class_3956<TripleWindowTopArch12Recipe>() {
            @Override
            public String toString() {
                return "triple_window_top_arch_1_2";
            }
        });
    
    public static void registerRecipes() {
        Architecture.LOGGER.info("Registering Custom Recipes for " + Architecture.MOD_ID);
    }
}

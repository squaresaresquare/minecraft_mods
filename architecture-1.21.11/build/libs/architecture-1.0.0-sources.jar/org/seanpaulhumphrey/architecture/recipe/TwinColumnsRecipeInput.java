package org.seanpaulhumphrey.architecture.recipe;
import net.minecraft.class_1799;
import net.minecraft.class_9695;

public record TwinColumnsRecipeInput(class_1799 input) implements class_9695 {
    @Override
    public class_1799 method_59984(int slot) {
        return input;
    }

    @Override
    public int method_59983() {
        return 1;
    }
}
    
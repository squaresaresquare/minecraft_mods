package org.seanpaulhumphrey.architecture.screen.custom;

    import net.minecraft.class_10799;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.seanpaulhumphrey.architecture.Architecture;

    public class QuadWindowTopArch16Screen extends class_465<QuadWindowTopArch16ScreenHandler> {
        public static final class_2960 GUI_TEXTURE =
                class_2960.method_60655(Architecture.MOD_ID, "textures/gui/pillar/pillar_gui.png");

        public QuadWindowTopArch16Screen(QuadWindowTopArch16ScreenHandler handler, class_1661 inventory, class_2561 title) {
            super(handler, inventory, title);
        }

        @Override
        protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
            int x = (field_22789 - field_2792) / 2;
            int y = (field_22790 - field_2779) / 2;

            context.method_25290(class_10799.field_56883, GUI_TEXTURE, x, y, 0, 0, field_2792, field_2779, 256, 256);
        }

        @Override
            public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
            super.method_25394(context, mouseX, mouseY, delta);
                method_2380(context, mouseX, mouseY);
        }
    }
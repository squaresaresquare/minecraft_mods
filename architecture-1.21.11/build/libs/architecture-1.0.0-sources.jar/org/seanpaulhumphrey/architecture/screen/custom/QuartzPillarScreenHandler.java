package org.seanpaulhumphrey.architecture.screen.custom;

        import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import org.seanpaulhumphrey.architecture.screen.ModScreenHandlers;

        public class QuartzPillarScreenHandler extends class_1703 {
            private final class_1263 inventory;

            public QuartzPillarScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos) {
                this(syncId, playerInventory, playerInventory.field_7546.method_73183().method_8321(pos));
        }

        public QuartzPillarScreenHandler(int syncId, class_1661 playerInventory, class_2586 blockEntity) {
            super(ModScreenHandlers.QUARTZ_PILLAR_SCREEN_HANDLER, syncId);
            this.inventory = ((class_1263) blockEntity);

            this.method_7621(new class_1735(inventory, 0, 80, 35) {
                @Override
                public int method_7675() {
                    return 1;
                }
            });

            addPlayerInventory(playerInventory);
            addPlayerHotbar(playerInventory);
        }

        @Override
        public class_1799 method_7601(class_1657 player, int invSlot) {
            class_1799 newStack = class_1799.field_8037;
            class_1735 slot = this.field_7761.get(invSlot);
            if (slot != null && slot.method_7681()) {
                class_1799 originalStack = slot.method_7677();
                newStack = originalStack.method_7972();
                if (invSlot < this.inventory.method_5439()) {
                    if (!this.method_7616(originalStack, this.inventory.method_5439(), this.field_7761.size(), true)) {
                        return class_1799.field_8037;
                    }
                } else if (!this.method_7616(originalStack, 0, this.inventory.method_5439(), false)) {
                    return class_1799.field_8037;
                }

                if (originalStack.method_7960()) {
                    slot.method_53512(class_1799.field_8037);
                } else {
                    slot.method_7668();
                }
            }
            return newStack;
        }

        @Override
        public boolean method_7597(class_1657 player) {
            return this.inventory.method_5443(player);
        }

        private void addPlayerInventory(class_1661 playerInventory) {
            for (int i = 0; i < 3; ++i) {
                for (int l = 0; l < 9; ++l) {
                    this.method_7621(new class_1735(playerInventory, l + i * 9 + 9, 8 + l * 18, 84 + i * 18));
                }
            }
        }

        private void addPlayerHotbar(class_1661 playerInventory) {
            for (int i = 0; i < 9; ++i) {
                this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
            }
        }
    }
    
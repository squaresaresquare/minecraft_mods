package org.seanpaulhumphrey.architecture.screen;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;
import org.seanpaulhumphrey.architecture.Architecture;
import org.seanpaulhumphrey.architecture.screen.custom.*;

public class ModScreenHandlers {
        public static final class_3917<TripleWindowTopArch11ScreenHandler> TRIPLE_WINDOW_TOP_ARCH_1_1_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_1_1_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowTopArch11ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowLeftBottomScreenHandler> TRIPLE_WINDOW_LEFT_BOTTOM_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_left_bottom_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowLeftBottomScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch22ScreenHandler> QUAD_WINDOW_TOP_ARCH_2_2_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_2_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch22ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowMiddleLeftScreenHandler> TRIPLE_WINDOW_MIDDLE_LEFT_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_middle_left_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowMiddleLeftScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<ThinQuartzBaseScreenHandler> THIN_QUARTZ_BASE_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "thin_quartz_base_screen_handler"),
        new ExtendedScreenHandlerType<>(ThinQuartzBaseScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch16ScreenHandler> QUAD_WINDOW_TOP_ARCH_1_6_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_6_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch16ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch23ScreenHandler> QUAD_WINDOW_TOP_ARCH_2_3_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_3_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch23ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TwinColumnCapitalScreenHandler> TWIN_COLUMN_CAPITAL_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "twin_column_capital_screen_handler"),
        new ExtendedScreenHandlerType<>(TwinColumnCapitalScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowCapLeftScreenHandler> TRIPLE_WINDOW_CAP_LEFT_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_cap_left_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowCapLeftScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch24ScreenHandler> QUAD_WINDOW_TOP_ARCH_2_4_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_4_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch24ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowTopCapMiddleScreenHandler> TRIPLE_WINDOW_TOP_CAP_MIDDLE_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_cap_middle_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowTopCapMiddleScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch11ScreenHandler> QUAD_WINDOW_TOP_ARCH_1_1_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_1_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch11ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowTopArchMiddleScreenHandler> TRIPLE_WINDOW_TOP_ARCH_MIDDLE_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_middle_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowTopArchMiddleScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowMiddleBottomScreenHandler> TRIPLE_WINDOW_MIDDLE_BOTTOM_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_middle_bottom_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowMiddleBottomScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowRightBottomScreenHandler> TRIPLE_WINDOW_RIGHT_BOTTOM_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_right_bottom_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowRightBottomScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowTopArch22ScreenHandler> TRIPLE_WINDOW_TOP_ARCH_2_2_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_2_2_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowTopArch22ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowTopArchLeftScreenHandler> TRIPLE_WINDOW_TOP_ARCH_LEFT_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_left_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowTopArchLeftScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<ThinQuartzColumnScreenHandler> THIN_QUARTZ_COLUMN_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "thin_quartz_column_screen_handler"),
        new ExtendedScreenHandlerType<>(ThinQuartzColumnScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowTopArch23ScreenHandler> TRIPLE_WINDOW_TOP_ARCH_2_3_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_2_3_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowTopArch23ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch25ScreenHandler> QUAD_WINDOW_TOP_ARCH_2_5_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_5_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch25ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch13ScreenHandler> QUAD_WINDOW_TOP_ARCH_1_3_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_3_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch13ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch26ScreenHandler> QUAD_WINDOW_TOP_ARCH_2_6_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_6_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch26ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TwinColumnsScreenHandler> TWIN_COLUMNS_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "twin_columns_screen_handler"),
        new ExtendedScreenHandlerType<>(TwinColumnsScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuartzPillarScreenHandler> QUARTZ_PILLAR_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quartz_pillar_screen_handler"),
        new ExtendedScreenHandlerType<>(QuartzPillarScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<HalfQuartzPillarScreenHandler> HALF_QUARTZ_PILLAR_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "half_quartz_pillar_screen_handler"),
        new ExtendedScreenHandlerType<>(HalfQuartzPillarScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch12ScreenHandler> QUAD_WINDOW_TOP_ARCH_1_2_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_2_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch12ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TwinColumnBaseScreenHandler> TWIN_COLUMN_BASE_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "twin_column_base_screen_handler"),
        new ExtendedScreenHandlerType<>(TwinColumnBaseScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowTopArch13ScreenHandler> TRIPLE_WINDOW_TOP_ARCH_1_3_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_1_3_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowTopArch13ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch15ScreenHandler> QUAD_WINDOW_TOP_ARCH_1_5_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_5_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch15ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch21ScreenHandler> QUAD_WINDOW_TOP_ARCH_2_1_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_2_1_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch21ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<QuadWindowTopArch14ScreenHandler> QUAD_WINDOW_TOP_ARCH_1_4_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "quad_window_top_arch_1_4_screen_handler"),
        new ExtendedScreenHandlerType<>(QuadWindowTopArch14ScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowMiddleMiddleScreenHandler> TRIPLE_WINDOW_MIDDLE_MIDDLE_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_middle_middle_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowMiddleMiddleScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<ThinQuartzCapitalScreenHandler> THIN_QUARTZ_CAPITAL_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "thin_quartz_capital_screen_handler"),
        new ExtendedScreenHandlerType<>(ThinQuartzCapitalScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowTopCapRightScreenHandler> TRIPLE_WINDOW_TOP_CAP_RIGHT_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_cap_right_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowTopCapRightScreenHandler::new, class_2338.field_48404));
                    
    public static final class_3917<TripleWindowTopArch12ScreenHandler> TRIPLE_WINDOW_TOP_ARCH_1_2_SCREEN_HANDLER =
    class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "triple_window_top_arch_1_2_screen_handler"),
        new ExtendedScreenHandlerType<>(TripleWindowTopArch12ScreenHandler::new, class_2338.field_48404));
                    

    public static void registerScreenHandlers() {
        Architecture.LOGGER.info("Registering Screen Handlers for " + Architecture.MOD_ID);
    }
}

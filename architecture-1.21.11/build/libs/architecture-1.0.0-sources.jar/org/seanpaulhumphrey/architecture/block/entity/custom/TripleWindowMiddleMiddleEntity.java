package org.seanpaulhumphrey.architecture.block.entity.custom;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import org.jetbrains.annotations.NotNull;
import org.seanpaulhumphrey.architecture.block.entity.ImplementedInventory;
import org.seanpaulhumphrey.architecture.block.entity.ModBlockEntities;
import org.seanpaulhumphrey.architecture.screen.custom.*;
import net.minecraft.block.entity.*;
import net.minecraft.class_10;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public class TripleWindowMiddleMiddleEntity extends class_2586 implements ImplementedInventory, ExtendedScreenHandlerFactory<@NotNull class_2338> {
    private final class_2371<class_1799> inventory = class_2371.method_10213(1, class_1799.field_8037);
    private float rotation = 0;

    //@Override
    public boolean canPathfindThrough(class_2680 state, class_1922 world, class_2338 pos, class_10 type) {
        // Return true if mobs can pass through, false otherwise
        return false;
    }

    public TripleWindowMiddleMiddleEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.TRIPLE_WINDOW_MIDDLE_MIDDLE_BE, pos, state);
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    public float getRenderingRotation() {
        rotation += 0.5f;
        if(rotation >= 360) {
            rotation = 0;
        }
        return rotation;
    }

    @Override
    protected void method_11007(class_11372 view) {
        super.method_11007(view);
        class_1262.method_5426(view, inventory);
    }

    @Override
    protected void method_11014(class_11368 view) {
        super.method_11014(view);
        class_1262.method_5429(view, inventory);
    }

    @Override
    public void method_66473(class_2338 pos, class_2680 oldState) {
        class_1264.method_5451(field_11863, pos, (this));
        super.method_66473(pos, oldState);
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470("TripleWindowMiddleMiddle");
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new TripleWindowMiddleMiddleScreenHandler(syncId, playerInventory, this.field_11867);
    }


    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}
    
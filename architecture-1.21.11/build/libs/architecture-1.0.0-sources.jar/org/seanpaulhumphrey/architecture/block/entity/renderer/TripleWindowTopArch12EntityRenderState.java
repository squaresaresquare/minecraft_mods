package org.seanpaulhumphrey.architecture.block.entity.renderer;

import net.minecraft.class_10444;
import net.minecraft.class_11954;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public class TripleWindowTopArch12EntityRenderState extends class_11954 {
    public class_2338 lightPosition;
    public class_1937 blockEntityWorld;
    public float rotation;

    final class_10444 itemRenderState = new class_10444();
}
    
package org.seanpaulhumphrey.architecture.block.entity.renderer;

import net.minecraft.class_10442;
import net.minecraft.class_11659;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_4587;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_827;
import org.seanpaulhumphrey.architecture.block.entity.custom.*;

public class QuadWindowTopArch24EntityRenderer implements class_827<QuadWindowTopArch24Entity, class_11954> {
    private final class_10442 itemModelManager;

    public QuadWindowTopArch24EntityRenderer(class_5614.class_5615 context) {
        itemModelManager = context.comp_4536();
    }

    @Override
    public QuadWindowTopArch24EntityRenderState method_74335() {
        return new QuadWindowTopArch24EntityRenderState();
    }

    @Override
    public void method_3569(class_11954 state, class_4587 matrices, class_11659 queue, class_12075 cameraRenderState) {

    }

    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, sLight);
    }
}
    
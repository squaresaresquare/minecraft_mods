package org.seanpaulhumphrey.architecture.block;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import org.seanpaulhumphrey.architecture.Architecture;
import org.seanpaulhumphrey.architecture.block.custom.*;
import org.seanpaulhumphrey.architecture.block.custom.*;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.Function;

public class ModBlocks {
    public static final class_2248 TRIPLE_WINDOW_TOP_ARCH_1_1 = registerBlock("triple_window_top_arch_1_1",
            properties -> new TripleWindowTopArch11(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_LEFT_BOTTOM = registerBlock("triple_window_left_bottom",
            properties -> new TripleWindowLeftBottom(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_2_2 = registerBlock("quad_window_top_arch_2_2",
            properties -> new QuadWindowTopArch22(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_MIDDLE_LEFT = registerBlock("triple_window_middle_left",
            properties -> new TripleWindowMiddleLeft(properties.method_22488()));
    public static final class_2248 THIN_QUARTZ_BASE = registerBlock("thin_quartz_base",
            properties -> new ThinQuartzBase(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_1_6 = registerBlock("quad_window_top_arch_1_6",
            properties -> new QuadWindowTopArch16(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_2_3 = registerBlock("quad_window_top_arch_2_3",
            properties -> new QuadWindowTopArch23(properties.method_22488()));
    public static final class_2248 TWIN_COLUMN_CAPITAL = registerBlock("twin_column_capital",
            properties -> new TwinColumnCapital(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_CAP_LEFT = registerBlock("triple_window_cap_left",
            properties -> new TripleWindowCapLeft(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_2_4 = registerBlock("quad_window_top_arch_2_4",
            properties -> new QuadWindowTopArch24(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_TOP_CAP_MIDDLE = registerBlock("triple_window_top_cap_middle",
            properties -> new TripleWindowTopCapMiddle(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_1_1 = registerBlock("quad_window_top_arch_1_1",
            properties -> new QuadWindowTopArch11(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_TOP_ARCH_MIDDLE = registerBlock("triple_window_top_arch_middle",
            properties -> new TripleWindowTopArchMiddle(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_MIDDLE_BOTTOM = registerBlock("triple_window_middle_bottom",
            properties -> new TripleWindowMiddleBottom(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_RIGHT_BOTTOM = registerBlock("triple_window_right_bottom",
            properties -> new TripleWindowRightBottom(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_TOP_ARCH_2_2 = registerBlock("triple_window_top_arch_2_2",
            properties -> new TripleWindowTopArch22(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_TOP_ARCH_LEFT = registerBlock("triple_window_top_arch_left",
            properties -> new TripleWindowTopArchLeft(properties.method_22488()));
    public static final class_2248 THIN_QUARTZ_COLUMN = registerBlock("thin_quartz_column",
            properties -> new ThinQuartzColumn(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_TOP_ARCH_2_3 = registerBlock("triple_window_top_arch_2_3",
            properties -> new TripleWindowTopArch23(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_2_5 = registerBlock("quad_window_top_arch_2_5",
            properties -> new QuadWindowTopArch25(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_1_3 = registerBlock("quad_window_top_arch_1_3",
            properties -> new QuadWindowTopArch13(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_2_6 = registerBlock("quad_window_top_arch_2_6",
            properties -> new QuadWindowTopArch26(properties.method_22488()));
    public static final class_2248 TWIN_COLUMNS = registerBlock("twin_columns",
            properties -> new TwinColumns(properties.method_22488()));
    public static final class_2248 QUARTZ_PILLAR = registerBlock("quartz_pillar",
            properties -> new QuartzPillar(properties.method_22488()));
    public static final class_2248 HALF_QUARTZ_PILLAR = registerBlock("half_quartz_pillar",
            properties -> new HalfQuartzPillar(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_1_2 = registerBlock("quad_window_top_arch_1_2",
            properties -> new QuadWindowTopArch12(properties.method_22488()));
    public static final class_2248 TWIN_COLUMN_BASE = registerBlock("twin_column_base",
            properties -> new TwinColumnBase(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_TOP_ARCH_1_3 = registerBlock("triple_window_top_arch_1_3",
            properties -> new TripleWindowTopArch13(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_1_5 = registerBlock("quad_window_top_arch_1_5",
            properties -> new QuadWindowTopArch15(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_2_1 = registerBlock("quad_window_top_arch_2_1",
            properties -> new QuadWindowTopArch21(properties.method_22488()));
    public static final class_2248 QUAD_WINDOW_TOP_ARCH_1_4 = registerBlock("quad_window_top_arch_1_4",
            properties -> new QuadWindowTopArch14(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_MIDDLE_MIDDLE = registerBlock("triple_window_middle_middle",
            properties -> new TripleWindowMiddleMiddle(properties.method_22488()));
    public static final class_2248 THIN_QUARTZ_CAPITAL = registerBlock("thin_quartz_capital",
            properties -> new ThinQuartzCapital(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_TOP_CAP_RIGHT = registerBlock("triple_window_top_cap_right",
            properties -> new TripleWindowTopCapRight(properties.method_22488()));
    public static final class_2248 TRIPLE_WINDOW_TOP_ARCH_1_2 = registerBlock("triple_window_top_arch_1_2",
            properties -> new TripleWindowTopArch12(properties.method_22488()));
private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> function) {
        class_2248 toRegister = function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Architecture.MOD_ID, name))));
        registerBlockItem(name, toRegister);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Architecture.MOD_ID, name), toRegister);
    }

    private static class_2248 registerBlockWithoutBlockItem(String name, Function<class_4970.class_2251, class_2248> function) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Architecture.MOD_ID, name),
                function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Architecture.MOD_ID, name)))));
    }

    private static void registerBlockItem(String name, class_2248 block) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Architecture.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Architecture.MOD_ID, name)))));
    }

    public static void registerModBlocks() {
        Architecture.LOGGER.info("Registering Mod Blocks for " + Architecture.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            entries.method_45421(ModBlocks.QUARTZ_PILLAR);
            entries.method_45421(ModBlocks.HALF_QUARTZ_PILLAR);
                entries.method_45421(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_1 );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_LEFT_BOTTOM );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_2 );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_MIDDLE_LEFT );
            entries.method_45421(ModBlocks.THIN_QUARTZ_BASE );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_6 );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_3 );
            entries.method_45421(ModBlocks.TWIN_COLUMN_CAPITAL );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_CAP_LEFT );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_4 );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_TOP_CAP_MIDDLE );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_1 );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_MIDDLE );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_MIDDLE_BOTTOM );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_RIGHT_BOTTOM );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_2 );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_LEFT );
            entries.method_45421(ModBlocks.THIN_QUARTZ_COLUMN );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_2_3 );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_5 );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_3 );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_6 );
            entries.method_45421(ModBlocks.TWIN_COLUMNS );
            entries.method_45421(ModBlocks.QUARTZ_PILLAR );
            entries.method_45421(ModBlocks.HALF_QUARTZ_PILLAR );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_2 );
            entries.method_45421(ModBlocks.TWIN_COLUMN_BASE );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_3 );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_5 );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_2_1 );
            entries.method_45421(ModBlocks.QUAD_WINDOW_TOP_ARCH_1_4 );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_MIDDLE_MIDDLE );
            entries.method_45421(ModBlocks.THIN_QUARTZ_CAPITAL );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_TOP_CAP_RIGHT );
            entries.method_45421(ModBlocks.TRIPLE_WINDOW_TOP_ARCH_1_2 );
            });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> {
            entries.method_45421(ModBlocks.QUARTZ_PILLAR);
        });
    }
}
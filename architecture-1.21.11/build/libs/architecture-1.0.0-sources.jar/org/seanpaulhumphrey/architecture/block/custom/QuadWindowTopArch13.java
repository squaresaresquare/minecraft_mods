package org.seanpaulhumphrey.architecture.block.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.world.level.LevelProperties.*;
import org.jetbrains.annotations.Nullable;
import org.seanpaulhumphrey.architecture.block.entity.custom.QuadWindowTopArch13Entity;

public class QuadWindowTopArch13 extends class_2237 implements class_2343 {
    public static final MapCodec<QuadWindowTopArch13> CODEC = QuadWindowTopArch13.method_54094(QuadWindowTopArch13::new);
    public QuadWindowTopArch13(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(class_2383.field_11177, class_2350.field_11043));
    }



    //the rest
    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new QuadWindowTopArch13Entity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos,
                                         class_1657 player, class_1268 hand, class_3965 hit) {
        if(world.method_8321(pos) instanceof QuadWindowTopArch13Entity QuadWindowTopArch13BlockEntity) {
            if(QuadWindowTopArch13BlockEntity.method_5442() && !stack.method_7960()) {
                QuadWindowTopArch13BlockEntity.method_5447(0, stack.method_46651(1));
                world.method_8396(player, pos, class_3417.field_15197, class_3419.field_15245, 1f, 2f);
                stack.method_7934(1);

                QuadWindowTopArch13BlockEntity.method_5431();
                world.method_8413(pos, state, state, 0);
            } else if(stack.method_7960() && !player.method_5715()) {
                class_1799 stackOnQuartzPillar = QuadWindowTopArch13BlockEntity.method_5438(0);
                player.method_6122(class_1268.field_5808, stackOnQuartzPillar);
                world.method_8396(player, pos, class_3417.field_15197, class_3419.field_15245, 1f, 1f);
                QuadWindowTopArch13BlockEntity.method_5448();

                QuadWindowTopArch13BlockEntity.method_5431();
                world.method_8413(pos, state, state, 0);
            } else if(player.method_5715() && !world.method_8608()) {
                player.method_17355(QuadWindowTopArch13BlockEntity);
            }
        }

        return class_1269.field_5812;
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(class_2383.field_11177, ctx.method_8042().method_10153());
    }
    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(class_2383.field_11177);
    }

    //collision detection part
    protected static final class_265 NORTH_SHAPE =
            class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 16.0, 16.0);
    protected static final class_265 SOUTH_SHAPE =
            class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 8.0);
    protected static final class_265 EAST_SHAPE =
            class_2248.method_9541(0.0, 0.0, 0.0, 8.0, 16.0, 16.0);
    protected static final class_265 WEST_SHAPE =
            class_2248.method_9541(8.0, 0.0, 0.0, 16.0, 16.0, 16.0);

    protected static final class_265 NORTH_HALFSHAPE =
            class_259.method_1081(0.0, 0.0, 8.0, 16.0, 16.0, 16.0);
    protected static final class_265 SOUTH_HALFSHAPE =
            class_259.method_1081(0.0, 0.0, 0.0, 16.0, 16.0, 8.0);
    protected static final class_265 EAST_HALFSHAPE =
            class_259.method_1081(0.0, 0.0, 0.0, 8.0, 16.0, 16.0);
    protected static final class_265 WEST_HALFSHAPE =
            class_259.method_1081(8.0, 0.0, 0.0, 16.0, 16.0, 16.0);

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(class_2383.field_11177)) {
            case field_11035 -> SOUTH_SHAPE;
            case field_11034 -> EAST_SHAPE;
            case field_11039 -> WEST_SHAPE;
            default -> NORTH_SHAPE;
        };
    }
    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(class_2383.field_11177)) {
            case field_11035 -> SOUTH_HALFSHAPE;
            case field_11034 -> EAST_HALFSHAPE;
            case field_11039 -> WEST_HALFSHAPE;
            default -> NORTH_HALFSHAPE;
        };
    }
}
    
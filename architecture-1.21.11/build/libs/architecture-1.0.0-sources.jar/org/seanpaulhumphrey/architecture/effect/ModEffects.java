package org.seanpaulhumphrey.architecture.effect;

import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import org.seanpaulhumphrey.architecture.Architecture;

public class ModEffects {
    private static class_6880<class_1291> registerStatusEffect(String name, class_1291 statusEffect) {
        return class_2378.method_47985(class_7923.field_41174, class_2960.method_60655(Architecture.MOD_ID, name), statusEffect);
    }

    public static void registerEffects() {
        Architecture.LOGGER.info("Registering Mod Effects for " + Architecture.MOD_ID);
    }
}

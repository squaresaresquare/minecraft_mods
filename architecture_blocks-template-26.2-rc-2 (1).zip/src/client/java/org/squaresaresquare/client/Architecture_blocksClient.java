package org.squaresaresquare.client;

import net.fabricmc.api.ClientModInitializer;

public class Architecture_blocksClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}
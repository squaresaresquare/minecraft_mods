package net.kaupenjoe.tutorialmod.trim;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.minecraft.class_10714;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_5251;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8054;
import java.util.Map;

public class ModTrimMaterials {
    public static final class_5321<class_8054> PINK_GARNET = class_5321.method_29179(class_7924.field_42083,
            class_2960.method_60655(TutorialMod.MOD_ID, "pink_garnet"));

    public static void bootstrap(class_7891<class_8054> registerable) {
        register(registerable, PINK_GARNET, class_7923.field_41178.method_47983(ModItems.PINK_GARNET),
                class_2583.field_24360.method_27703(class_5251.method_27719("#b03fe0").getOrThrow()));

    }

    private static void register(class_7891<class_8054> registerable, class_5321<class_8054> armorTrimKey,
                                 class_6880<class_1792> item, class_2583 style) {
        class_8054 trimMaterial = new class_8054(class_10714.method_67229("pink_garnet"),
                class_2561.method_43471(class_156.method_646("trim_material", armorTrimKey.method_29177())).method_27696(style));

        registerable.method_46838(armorTrimKey, trimMaterial);
    }
}

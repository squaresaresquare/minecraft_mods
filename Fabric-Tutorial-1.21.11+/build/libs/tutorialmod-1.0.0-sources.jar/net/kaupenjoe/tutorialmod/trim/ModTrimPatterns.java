package net.kaupenjoe.tutorialmod.trim;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_8056;

public class ModTrimPatterns {
    public static final class_5321<class_8056> KAUPEN = class_5321.method_29179(class_7924.field_42082,
            class_2960.method_60655(TutorialMod.MOD_ID, "kaupen"));

    public static void bootstrap(class_7891<class_8056> context) {
        register(context, ModItems.KAUPEN_SMITHING_TEMPLATE, KAUPEN);
    }

    private static void register(class_7891<class_8056> context, class_1792 item, class_5321<class_8056> key) {
        class_8056 trimPattern = new class_8056(key.method_29177(),
                class_2561.method_43471(class_156.method_646("trim_pattern", key.method_29177())), false);

        context.method_46838(key, trimPattern);
    }
}
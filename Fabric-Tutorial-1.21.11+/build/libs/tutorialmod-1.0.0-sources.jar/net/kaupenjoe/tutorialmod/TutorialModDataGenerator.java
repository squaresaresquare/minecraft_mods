package net.kaupenjoe.tutorialmod;

import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.kaupenjoe.tutorialmod.datagen.*;
import net.kaupenjoe.tutorialmod.enchantment.ModEnchantments;
import net.kaupenjoe.tutorialmod.trim.ModTrimMaterials;
import net.kaupenjoe.tutorialmod.trim.ModTrimPatterns;
import net.kaupenjoe.tutorialmod.world.ModConfiguredFeatures;
import net.kaupenjoe.tutorialmod.world.ModPlacedFeatures;
import net.minecraft.class_7877;
import net.minecraft.class_7924;

public class TutorialModDataGenerator implements DataGeneratorEntrypoint {
	@Override
	public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
		FabricDataGenerator.Pack pack = fabricDataGenerator.createPack();

		pack.addProvider(ModBlockTagProvider::new);
		pack.addProvider(ModItemTagProvider::new);
		pack.addProvider(ModLootTableProvider::new);
		pack.addProvider(ModModelProvider::new);
		pack.addProvider(ModRecipeProvider::new);
		pack.addProvider(ModRegistryDataGenerator::new);
	}

	@Override
	public void buildRegistry(class_7877 registryBuilder) {
		registryBuilder.method_46777(class_7924.field_42083, ModTrimMaterials::bootstrap);
		registryBuilder.method_46777(class_7924.field_42082, ModTrimPatterns::bootstrap);
		registryBuilder.method_46777(class_7924.field_41265, ModEnchantments::bootstrap);

		registryBuilder.method_46777(class_7924.field_41239, ModConfiguredFeatures::bootstrap);
		registryBuilder.method_46777(class_7924.field_41245, ModPlacedFeatures::bootstrap);
	}
}

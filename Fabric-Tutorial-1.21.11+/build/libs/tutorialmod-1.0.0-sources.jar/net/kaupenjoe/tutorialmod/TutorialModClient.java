package net.kaupenjoe.tutorialmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.kaupenjoe.tutorialmod.block.entity.ModBlockEntities;
import net.kaupenjoe.tutorialmod.block.entity.renderer.PedestalBlockEntityRenderer;
import net.kaupenjoe.tutorialmod.entity.ModEntities;
import net.kaupenjoe.tutorialmod.entity.client.*;
import net.kaupenjoe.tutorialmod.particle.ModParticles;
import net.kaupenjoe.tutorialmod.particle.PinkGarnetParticle;
import net.kaupenjoe.tutorialmod.screen.ModScreenHandlers;
import net.kaupenjoe.tutorialmod.screen.custom.GrowthChamberScreen;
import net.kaupenjoe.tutorialmod.screen.custom.PedestalScreen;
import net.minecraft.class_11515;
import net.minecraft.class_3929;
import net.minecraft.class_5616;

public class TutorialModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.putBlock(ModBlocks.PINK_GARNET_DOOR, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.PINK_GARNET_TRAPDOOR, class_11515.field_60925);

        BlockRenderLayerMap.putBlock(ModBlocks.CAULIFLOWER_CROP, class_11515.field_60925);
        BlockRenderLayerMap.putBlock(ModBlocks.HONEY_BERRY_BUSH, class_11515.field_60925);

        BlockRenderLayerMap.putBlock(ModBlocks.DRIFTWOOD_SAPLING, class_11515.field_60925);

        EntityModelLayerRegistry.registerModelLayer(MantisModel.MANTIS, MantisModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.MANTIS, MantisRenderer::new);

        EntityModelLayerRegistry.registerModelLayer(TomahawkProjectileModel.TOMAHAWK, TomahawkProjectileModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.TOMAHAWK, TomahawkProjectileRenderer::new);

        EntityRendererRegistry.register(ModEntities.CHAIR, ChairRenderer::new);

        ParticleFactoryRegistry.getInstance().register(ModParticles.PINK_GARNET_PARTICLE, PinkGarnetParticle.Factory::new);

        class_5616.method_32144(ModBlockEntities.PEDESTAL_BE, PedestalBlockEntityRenderer::new);
        class_3929.method_17542(ModScreenHandlers.PEDESTAL_SCREEN_HANDLER, PedestalScreen::new);

        class_3929.method_17542(ModScreenHandlers.GROWTH_CHAMBER_SCREEN_HANDLER, GrowthChamberScreen::new);
    }
}

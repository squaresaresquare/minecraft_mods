package net.kaupenjoe.tutorialmod.datagen;

import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.kaupenjoe.tutorialmod.block.custom.CauliflowerCropBlock;
import net.kaupenjoe.tutorialmod.block.custom.HoneyBerryBushBlock;
import net.kaupenjoe.tutorialmod.block.custom.PinkGarnetLampBlock;
import net.kaupenjoe.tutorialmod.component.ModDataComponentTypes;
import net.kaupenjoe.tutorialmod.item.ModArmorMaterials;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.minecraft.class_10410;
import net.minecraft.class_10434;
import net.minecraft.class_10437;
import net.minecraft.class_10439;
import net.minecraft.class_10464;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4925;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4946;
import net.minecraft.class_6012;
import net.minecraft.class_807;
import net.minecraft.class_813;
import net.minecraft.client.data.*;
import java.util.Optional;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        class_4910.class_4912 pinkGarnetPool = blockStateModelGenerator.method_25650(ModBlocks.PINK_GARNET_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.RAW_PINK_GARNET_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.PINK_GARNET_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.PINK_GARNET_DEEPSLATE_ORE);

        blockStateModelGenerator.method_25641(ModBlocks.PINK_GARNET_NETHER_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.PINK_GARNET_END_ORE);

        blockStateModelGenerator.method_25641(ModBlocks.MAGIC_BLOCK);

        pinkGarnetPool.method_25725(ModBlocks.PINK_GARNET_STAIRS);
        pinkGarnetPool.method_25724(ModBlocks.PINK_GARNET_SLAB);

        pinkGarnetPool.method_25716(ModBlocks.PINK_GARNET_BUTTON);
        pinkGarnetPool.method_25723(ModBlocks.PINK_GARNET_PRESSURE_PLATE);

        pinkGarnetPool.method_25721(ModBlocks.PINK_GARNET_FENCE);
        pinkGarnetPool.method_25722(ModBlocks.PINK_GARNET_FENCE_GATE);
        pinkGarnetPool.method_25720(ModBlocks.PINK_GARNET_WALL);

        blockStateModelGenerator.method_25658(ModBlocks.PINK_GARNET_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.PINK_GARNET_TRAPDOOR);

        class_2960 lampOffIdentifier = class_4946.field_23036.method_25923(ModBlocks.PINK_GARNET_LAMP, blockStateModelGenerator.field_22831);
        class_2960 lampOnIdentifier = blockStateModelGenerator.method_25557(ModBlocks.PINK_GARNET_LAMP, "_on", class_4943.field_22972, class_4944::method_25875);
        blockStateModelGenerator.field_22830.accept(class_4925.method_67852(ModBlocks.PINK_GARNET_LAMP)
                .method_67859(class_4910.method_25565(PinkGarnetLampBlock.CLICKED,
                        new class_807(class_6012.<class_813>method_66215().method_54453(new class_813(lampOnIdentifier)).method_34974()),
                        new class_807(class_6012.<class_813>method_66215().method_54453(new class_813(lampOffIdentifier)).method_34974()))));

        blockStateModelGenerator.method_25547(ModBlocks.CAULIFLOWER_CROP, CauliflowerCropBlock.AGE, 0, 1, 2, 3, 4, 5, 6);
        blockStateModelGenerator.method_49374(ModBlocks.HONEY_BERRY_BUSH, class_4910.class_4913.field_22840,
                HoneyBerryBushBlock.field_17000, 0, 1, 2, 3);

        blockStateModelGenerator.method_25676(ModBlocks.DRIFTWOOD_LOG).method_25730(ModBlocks.DRIFTWOOD_LOG).method_25728(ModBlocks.DRIFTWOOD_WOOD);
        blockStateModelGenerator.method_25676(ModBlocks.STRIPPED_DRIFTWOOD_LOG).method_25730(ModBlocks.STRIPPED_DRIFTWOOD_LOG).method_25728(ModBlocks.STRIPPED_DRIFTWOOD_WOOD);

        blockStateModelGenerator.method_25641(ModBlocks.DRIFTWOOD_PLANKS);
        blockStateModelGenerator.method_25622(ModBlocks.DRIFTWOOD_LEAVES, class_4946.field_23049);
        blockStateModelGenerator.method_25603(ModBlocks.DRIFTWOOD_SAPLING, class_4910.class_4913.field_22840);

        blockStateModelGenerator.method_25708(ModBlocks.CHAIR);

        blockStateModelGenerator.method_25641(ModBlocks.GROWTH_CHAMBER);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_65442(ModItems.PINK_GARNET, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.RAW_PINK_GARNET, class_4943.field_22938);

        itemModelGenerator.method_65442(ModItems.CAULIFLOWER, class_4943.field_22938);
        // itemModelGenerator.register(ModItems.CHISEL, Models.GENERATED);
        itemModelGenerator.method_65442(ModItems.STARLIGHT_ASHES, class_4943.field_22938);

        itemModelGenerator.method_65442(ModItems.PINK_GARNET_SWORD, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.PINK_GARNET_PICKAXE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.PINK_GARNET_SHOVEL, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.PINK_GARNET_AXE, class_4943.field_22939);
        itemModelGenerator.method_65442(ModItems.PINK_GARNET_HOE, class_4943.field_22939);

        itemModelGenerator.method_65442(ModItems.PINK_GARNET_HAMMER, class_4943.field_22939);

        itemModelGenerator.method_65434(ModItems.KAUPEN_BOW, class_4943.field_55255);
        itemModelGenerator.method_65446(ModItems.KAUPEN_BOW);

        itemModelGenerator.method_65429(ModItems.PINK_GARNET_HELMET, ModArmorMaterials.PINK_GARNET_KEY, class_4915.field_56347, false);
        itemModelGenerator.method_65429(ModItems.PINK_GARNET_CHESTPLATE, ModArmorMaterials.PINK_GARNET_KEY, class_4915.field_56348, false);
        itemModelGenerator.method_65429(ModItems.PINK_GARNET_LEGGINGS, ModArmorMaterials.PINK_GARNET_KEY, class_4915.field_56349, false);
        itemModelGenerator.method_65429(ModItems.PINK_GARNET_BOOTS, ModArmorMaterials.PINK_GARNET_KEY, class_4915.field_56350, false);

        itemModelGenerator.method_65442(ModItems.PINK_GARNET_HORSE_ARMOR, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.KAUPEN_SMITHING_TEMPLATE, class_4943.field_22938);

        itemModelGenerator.method_65442(ModItems.BAR_BRAWL_MUSIC_DISC, class_4943.field_22938);

        itemModelGenerator.method_65442(ModBlocks.DRIFTWOOD_SAPLING.method_8389(), class_4943.field_22938);

        itemModelGenerator.method_65442(ModItems.MANTIS_SPAWN_EGG,
                new class_4942(Optional.of(class_2960.method_60654("item/template_spawn_egg")), Optional.empty()));

        class_10439.class_10441 unbakedChisel = class_10410.method_65481(itemModelGenerator.method_65434(ModItems.CHISEL, class_4943.field_22938));
        class_10439.class_10441 unbakedUsedChisel = class_10410.method_65481(itemModelGenerator.method_65438(ModItems.CHISEL, "_used", class_4943.field_22938));
        itemModelGenerator.field_55245.method_75343(ModItems.CHISEL,
                new class_10434(new class_10437.class_10438(new class_10464(ModDataComponentTypes.COORDINATES, false),
                        unbakedUsedChisel, unbakedChisel),
                        new class_10434.class_10543(false, false, 1f)).comp_3385());
    }
}

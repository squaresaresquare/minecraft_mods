package net.kaupenjoe.tutorialmod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.kaupenjoe.tutorialmod.trim.ModTrimPatterns;
import net.minecraft.class_1935;
import net.minecraft.class_2446;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7924;
import net.minecraft.class_8790;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class ModRecipeProvider extends FabricRecipeProvider {
    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 recipeExporter) {
        return new class_2446(wrapperLookup, recipeExporter) {
            @Override
            public void method_10419() {
                List<class_1935> PINK_GARNET_SMELTABLES = List.of(ModItems.RAW_PINK_GARNET, ModBlocks.PINK_GARNET_ORE,
                        ModBlocks.PINK_GARNET_DEEPSLATE_ORE);

                method_36233(PINK_GARNET_SMELTABLES, class_7800.field_40642, ModItems.PINK_GARNET, 0.25f, 200, "pink_garnet");
                method_36234(PINK_GARNET_SMELTABLES, class_7800.field_40642, ModItems.PINK_GARNET, 0.25f, 100, "pink_garnet");

                method_36325(class_7800.field_40634, ModItems.PINK_GARNET, class_7800.field_40635, ModBlocks.PINK_GARNET_BLOCK);

                method_62746(class_7800.field_40642, ModBlocks.RAW_PINK_GARNET_BLOCK)
                        .method_10439("RRR")
                        .method_10439("RRR")
                        .method_10439("RRR")
                        .method_10434('R', ModItems.RAW_PINK_GARNET)
                        .method_10429(method_32807(ModItems.RAW_PINK_GARNET), method_10426(ModItems.RAW_PINK_GARNET))
                        .method_10431(field_53721);

                method_62750(class_7800.field_40642, ModItems.RAW_PINK_GARNET, 9)
                        .method_10454(ModBlocks.RAW_PINK_GARNET_BLOCK)
                        .method_10442(method_32807(ModBlocks.RAW_PINK_GARNET_BLOCK), method_10426(ModBlocks.RAW_PINK_GARNET_BLOCK))
                        .method_10431(field_53721);

                method_62750(class_7800.field_40642, ModItems.RAW_PINK_GARNET, 32)
                        .method_10454(ModBlocks.MAGIC_BLOCK)
                        .method_10442(method_32807(ModBlocks.MAGIC_BLOCK), method_10426(ModBlocks.MAGIC_BLOCK))
                        .method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TutorialMod.MOD_ID, "raw_pink_garnet_from_magic_block")));

                method_48530(ModItems.KAUPEN_SMITHING_TEMPLATE, ModTrimPatterns.KAUPEN,
                        class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TutorialMod.MOD_ID, "kaupen")));
            }
        };
    }

    @Override
    public String method_10321() {
        return "TutorialMod Recipes";
    }
}

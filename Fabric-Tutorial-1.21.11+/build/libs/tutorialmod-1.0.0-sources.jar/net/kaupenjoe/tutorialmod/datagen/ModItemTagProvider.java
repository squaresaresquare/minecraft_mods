package net.kaupenjoe.tutorialmod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.kaupenjoe.tutorialmod.util.ModTags;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public ModItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        valueLookupBuilder(ModTags.Items.TRANSFORMABLE_ITEMS)
                .method_71554(ModItems.PINK_GARNET)
                .method_71554(ModItems.RAW_PINK_GARNET)
                .method_71554(class_1802.field_8713)
                .method_71554(class_1802.field_8600)
                .method_71554(class_1802.field_8279);

        valueLookupBuilder(ModTags.Items.PINK_GARNET_REPAIR)
                .method_71554(ModItems.PINK_GARNET);

        valueLookupBuilder(class_3489.field_42611)
                .method_71554(ModItems.PINK_GARNET_SWORD);
        valueLookupBuilder(class_3489.field_42614)
                .method_71554(ModItems.PINK_GARNET_PICKAXE);
        valueLookupBuilder(class_3489.field_42615)
                .method_71554(ModItems.PINK_GARNET_SHOVEL);
        valueLookupBuilder(class_3489.field_42612)
                .method_71554(ModItems.PINK_GARNET_AXE);
        valueLookupBuilder(class_3489.field_42613)
                .method_71554(ModItems.PINK_GARNET_HOE);

        valueLookupBuilder(class_3489.field_41890)
                .method_71554(ModItems.PINK_GARNET_HELMET)
                .method_71554(ModItems.PINK_GARNET_CHESTPLATE)
                .method_71554(ModItems.PINK_GARNET_LEGGINGS)
                .method_71554(ModItems.PINK_GARNET_BOOTS);

        valueLookupBuilder(class_3489.field_41891)
                .method_71554(ModItems.PINK_GARNET);

        valueLookupBuilder(class_3489.field_23212)
                .method_71554(ModBlocks.DRIFTWOOD_LOG.method_8389())
                .method_71554(ModBlocks.DRIFTWOOD_WOOD.method_8389())
                .method_71554(ModBlocks.STRIPPED_DRIFTWOOD_LOG.method_8389())
                .method_71554(ModBlocks.STRIPPED_DRIFTWOOD_WOOD.method_8389());

        valueLookupBuilder(class_3489.field_15537)
                .method_71554(ModBlocks.DRIFTWOOD_PLANKS.method_8389());
    }
}

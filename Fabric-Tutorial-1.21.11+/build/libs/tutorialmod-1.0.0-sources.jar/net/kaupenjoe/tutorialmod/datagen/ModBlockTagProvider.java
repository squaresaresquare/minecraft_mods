package net.kaupenjoe.tutorialmod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.kaupenjoe.tutorialmod.util.ModTags;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {
    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        valueLookupBuilder(class_3481.field_33715)
                .method_71554(ModBlocks.PINK_GARNET_BLOCK)
                .method_71554(ModBlocks.RAW_PINK_GARNET_BLOCK)
                .method_71554(ModBlocks.PINK_GARNET_ORE)
                .method_71554(ModBlocks.PINK_GARNET_DEEPSLATE_ORE)
                .method_71554(ModBlocks.MAGIC_BLOCK);

        valueLookupBuilder(class_3481.field_33718)
                .method_71554(ModBlocks.PINK_GARNET_DEEPSLATE_ORE);

        valueLookupBuilder(class_3481.field_16584).method_71554(ModBlocks.PINK_GARNET_FENCE);
        valueLookupBuilder(class_3481.field_25147).method_71554(ModBlocks.PINK_GARNET_FENCE_GATE);
        valueLookupBuilder(class_3481.field_15504).method_71554(ModBlocks.PINK_GARNET_WALL);

        valueLookupBuilder(class_3481.field_33717)
                .method_71554(ModBlocks.MAGIC_BLOCK);

        valueLookupBuilder(ModTags.Blocks.NEEDS_PINK_GARNET_TOOL)
                .method_71554(ModBlocks.MAGIC_BLOCK)
                .method_71553(class_3481.field_33718);

        valueLookupBuilder(class_3481.field_23210)
                .method_71554(ModBlocks.DRIFTWOOD_LOG)
                .method_71554(ModBlocks.DRIFTWOOD_WOOD)
                .method_71554(ModBlocks.STRIPPED_DRIFTWOOD_LOG)
                .method_71554(ModBlocks.STRIPPED_DRIFTWOOD_WOOD);
    }
}

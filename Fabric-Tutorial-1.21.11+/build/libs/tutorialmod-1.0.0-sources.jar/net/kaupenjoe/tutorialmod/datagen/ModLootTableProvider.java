package net.kaupenjoe.tutorialmod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.kaupenjoe.tutorialmod.block.custom.CauliflowerCropBlock;
import net.kaupenjoe.tutorialmod.block.custom.HoneyBerryBushBlock;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.minecraft.class_141;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_212;
import net.minecraft.class_2248;
import net.minecraft.class_4559;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import net.minecraft.class_7924;
import net.minecraft.class_85;
import net.minecraft.class_94;
import java.util.concurrent.CompletableFuture;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {
        class_7225.class_7226<class_1887> impl = this.field_51845.method_46762(class_7924.field_41265);

        method_46025(ModBlocks.PINK_GARNET_BLOCK);
        method_46025(ModBlocks.RAW_PINK_GARNET_BLOCK);
        method_46025(ModBlocks.MAGIC_BLOCK);

        method_45988(ModBlocks.PINK_GARNET_ORE, method_45981(ModBlocks.PINK_GARNET_ORE, ModItems.RAW_PINK_GARNET));
        method_45988(ModBlocks.PINK_GARNET_DEEPSLATE_ORE, multipleOreDrops(ModBlocks.PINK_GARNET_DEEPSLATE_ORE, ModItems.RAW_PINK_GARNET, 3, 7));

        method_46025(ModBlocks.PINK_GARNET_STAIRS);
        method_45988(ModBlocks.PINK_GARNET_SLAB, method_45980(ModBlocks.PINK_GARNET_SLAB));

        method_46025(ModBlocks.PINK_GARNET_BUTTON);
        method_46025(ModBlocks.PINK_GARNET_PRESSURE_PLATE);

        method_46025(ModBlocks.PINK_GARNET_WALL);
        method_46025(ModBlocks.PINK_GARNET_FENCE);
        method_46025(ModBlocks.PINK_GARNET_FENCE_GATE);

        method_45988(ModBlocks.PINK_GARNET_DOOR, method_46022(ModBlocks.PINK_GARNET_DOOR));
        method_46025(ModBlocks.PINK_GARNET_TRAPDOOR);

        class_212.class_213 builder2 = class_212.method_900(ModBlocks.CAULIFLOWER_CROP)
                .method_22584(class_4559.class_4560.method_22523().method_22524(CauliflowerCropBlock.AGE, CauliflowerCropBlock.MAX_AGE));
        this.method_45988(ModBlocks.CAULIFLOWER_CROP, this.method_45982(ModBlocks.CAULIFLOWER_CROP, ModItems.CAULIFLOWER, ModItems.CAULIFLOWER_SEEDS, builder2));

        this.method_45994(ModBlocks.HONEY_BERRY_BUSH,
                block -> this.method_45977(
                        block,class_52.method_324().method_336(class_55.method_347().method_356(
                                                        class_212.method_900(ModBlocks.HONEY_BERRY_BUSH).method_22584(class_4559.class_4560.method_22523().method_22524(HoneyBerryBushBlock.field_17000, 3))
                                                )
                                                .method_351(class_77.method_411(ModItems.HONEY_BERRIES))
                                                .method_353(class_141.method_621(class_5662.method_32462(2.0F, 3.0F)))
                                                .method_353(class_94.method_456(impl.method_46747(class_1893.field_9130)))
                                ).method_336(class_55.method_347().method_356(
                                                        class_212.method_900(ModBlocks.HONEY_BERRY_BUSH).method_22584(class_4559.class_4560.method_22523().method_22524(HoneyBerryBushBlock.field_17000, 2))
                                                ).method_351(class_77.method_411(ModItems.HONEY_BERRIES))
                                                .method_353(class_141.method_621(class_5662.method_32462(1.0F, 2.0F)))
                                                .method_353(class_94.method_456(impl.method_46747(class_1893.field_9130))))));


        method_45988(ModBlocks.PINK_GARNET_END_ORE, multipleOreDrops(ModBlocks.PINK_GARNET_END_ORE, ModItems.RAW_PINK_GARNET, 4, 9));
        method_45988(ModBlocks.PINK_GARNET_NETHER_ORE, multipleOreDrops(ModBlocks.PINK_GARNET_NETHER_ORE, ModItems.RAW_PINK_GARNET, 3, 8));

        method_46025(ModBlocks.DRIFTWOOD_LOG);
        method_46025(ModBlocks.DRIFTWOOD_WOOD);
        method_46025(ModBlocks.STRIPPED_DRIFTWOOD_LOG);
        method_46025(ModBlocks.STRIPPED_DRIFTWOOD_WOOD);
        method_46025(ModBlocks.DRIFTWOOD_PLANKS);
        method_46025(ModBlocks.DRIFTWOOD_SAPLING);

        method_45988(ModBlocks.DRIFTWOOD_LEAVES, method_45986(ModBlocks.DRIFTWOOD_LEAVES, ModBlocks.DRIFTWOOD_SAPLING, 0.0625f));
    }

    public class_52.class_53 multipleOreDrops(class_2248 drop, class_1792 item, float minDrops, float maxDrops) {
        class_7225.class_7226<class_1887> impl = this.field_51845.method_46762(class_7924.field_41265);
        return this.method_45989(drop, this.method_45977(drop, ((class_85.class_86<?>)
                class_77.method_411(item).method_438(class_141.method_621(class_5662.method_32462(minDrops, maxDrops))))
                .method_438(class_94.method_455(impl.method_46747(class_1893.field_9130)))));
    }
}

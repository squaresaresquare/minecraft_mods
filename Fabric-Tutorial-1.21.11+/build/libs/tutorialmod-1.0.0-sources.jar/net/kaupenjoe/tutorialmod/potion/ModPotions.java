package net.kaupenjoe.tutorialmod.potion;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.effect.ModEffects;
import net.minecraft.class_1293;
import net.minecraft.class_1842;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class ModPotions {
    public static final class_6880<class_1842> SLIMEY_POTION = registerPotion("slimey_potion",
            new class_1842("slimey_potion", new class_1293(ModEffects.SLIMEY, 1200, 0)));


    private static class_6880<class_1842> registerPotion(String name, class_1842 potion) {
        return class_2378.method_47985(class_7923.field_41179, class_2960.method_60655(TutorialMod.MOD_ID, name), potion);
    }

    public static void registerPotions() {
        TutorialMod.LOGGER.info("Registering Mod Potions for " + TutorialMod.MOD_ID);
    }
}

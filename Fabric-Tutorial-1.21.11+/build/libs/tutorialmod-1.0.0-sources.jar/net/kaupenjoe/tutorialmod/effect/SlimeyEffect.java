package net.kaupenjoe.tutorialmod.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_4081;

// Climbing Effect by SameDifferent: https://github.com/samedifferent/TrickOrTreat/blob/master/LICENSE
// MIT License!
public class SlimeyEffect extends class_1291 {
    public SlimeyEffect(class_4081 category, int color) {
        super(category, color);
    }

    @Override
    public boolean method_5572(class_3218 world, class_1309 entity, int amplifier) {
        if(entity.field_5976) {
            class_243 initialVec = entity.method_18798();
            class_243 climbVec = new class_243(initialVec.field_1352, 0.2D, initialVec.field_1350);
            entity.method_18799(climbVec.method_1021(0.96D));
            return true;
        }

        return super.method_5572(world, entity, amplifier);
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true;
    }
}

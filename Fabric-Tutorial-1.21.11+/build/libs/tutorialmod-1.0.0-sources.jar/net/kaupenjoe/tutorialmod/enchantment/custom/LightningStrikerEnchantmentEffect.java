package net.kaupenjoe.tutorialmod.enchantment.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_9699;
import net.minecraft.class_9721;

public record LightningStrikerEnchantmentEffect() implements class_9721 {
    public static final MapCodec<LightningStrikerEnchantmentEffect> CODEC = MapCodec.unit(LightningStrikerEnchantmentEffect::new);

    @Override
    public void method_60220(class_3218 world, int level, class_9699 context, class_1297 user, class_243 pos) {
        if(level == 1) {
            class_1299.field_6112.method_47821(world, user.method_24515(), class_3730.field_16461);
        }

        if(level == 2) {
            class_1299.field_6112.method_47821(world, user.method_24515(), class_3730.field_16461);
            class_1299.field_6112.method_47821(world, user.method_24515(), class_3730.field_16461);
        }
    }

    @Override
    public MapCodec<? extends class_9721> method_60219() {
        return CODEC;
    }
}

package net.kaupenjoe.tutorialmod.enchantment;

import com.mojang.serialization.MapCodec;
import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.enchantment.custom.LightningStrikerEnchantmentEffect;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9721;

public class ModEnchantmentEffects {
    public static final MapCodec<? extends class_9721> LIGHTNING_STRIKER =
            registerEntityEffect("lightning_striker", LightningStrikerEnchantmentEffect.CODEC);


    private static MapCodec<? extends class_9721> registerEntityEffect(String name,
                                                                                    MapCodec<? extends class_9721> codec) {
        return class_2378.method_10230(class_7923.field_51834, class_2960.method_60655(TutorialMod.MOD_ID, name), codec);
    }

    public static void registerEnchantmentEffects() {
        TutorialMod.LOGGER.info("Registering Mod Enchantment Effects for " + TutorialMod.MOD_ID);
    }
}

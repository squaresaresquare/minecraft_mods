package net.kaupenjoe.tutorialmod.enchantment;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.enchantment.custom.LightningStrikerEnchantmentEffect;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_9274;
import net.minecraft.class_9636;
import net.minecraft.class_9701;
import net.minecraft.class_9703;

public class ModEnchantments {
    public static final class_5321<class_1887> LIGHTNING_STRIKER =
            class_5321.method_29179(class_7924.field_41265, class_2960.method_60655(TutorialMod.MOD_ID, "lightning_striker"));

    public static void bootstrap(class_7891<class_1887> registerable) {
        var enchantments = registerable.method_46799(class_7924.field_41265);
        var items = registerable.method_46799(class_7924.field_41197);

        register(registerable, LIGHTNING_STRIKER, class_1887.method_60030(class_1887.method_58442(
                items.method_46735(class_3489.field_48305),
                5,
                2,
                class_1887.method_58441(5, 7),
                class_1887.method_58441(25, 9),
                2,
                class_9274.field_49217))
                .method_60061(enchantments.method_46735(class_9636.field_51542))
                .method_60063(class_9701.field_51665,
                        class_9703.field_51683, class_9703.field_51685,
                        new LightningStrikerEnchantmentEffect()));
    }


    private static void register(class_7891<class_1887> registry, class_5321<class_1887> key, class_1887.class_9700 builder) {
        registry.method_46838(key, builder.method_60060(key.method_29177()));
    }
}

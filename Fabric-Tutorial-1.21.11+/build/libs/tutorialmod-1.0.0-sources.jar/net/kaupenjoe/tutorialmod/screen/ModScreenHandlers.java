package net.kaupenjoe.tutorialmod.screen;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.screen.custom.GrowthChamberScreenHandler;
import net.kaupenjoe.tutorialmod.screen.custom.PedestalScreenHandler;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class ModScreenHandlers {
    public static final class_3917<PedestalScreenHandler> PEDESTAL_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(TutorialMod.MOD_ID, "pedestal_screen_handler"),
                    new ExtendedScreenHandlerType<>(PedestalScreenHandler::new, class_2338.field_48404));

    public static final class_3917<GrowthChamberScreenHandler> GROWTH_CHAMBER_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(TutorialMod.MOD_ID, "growth_chamber_screen_handler"),
                    new ExtendedScreenHandlerType<>(GrowthChamberScreenHandler::new, class_2338.field_48404));


    public static void registerScreenHandlers() {
        TutorialMod.LOGGER.info("Registering Screen Handlers for " + TutorialMod.MOD_ID);
    }
}

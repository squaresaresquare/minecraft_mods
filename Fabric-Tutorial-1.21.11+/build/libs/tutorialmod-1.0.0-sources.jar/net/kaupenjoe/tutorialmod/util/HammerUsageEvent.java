package net.kaupenjoe.tutorialmod.util;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.kaupenjoe.tutorialmod.item.custom.HammerItem;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;

public class HammerUsageEvent implements PlayerBlockBreakEvents.Before{
    // Done with the help of https://github.com/CoFH/CoFHCore/blob/c23d117dcd3b3b3408a138716b15507f709494cd/src/main/java/cofh/core/event/AreaEffectEvents.java
    private static final Set<class_2338> HARVESTED_BLOCKS = new HashSet<>();

    @Override
    public boolean beforeBlockBreak(class_1937 world, class_1657 player, class_2338 pos,
                                    class_2680 state, @Nullable class_2586 blockEntity) {
        class_1799 mainHandItem = player.method_6047();

        if(mainHandItem.method_7909() instanceof HammerItem hammer && player instanceof class_3222 serverPlayer) {
            if(HARVESTED_BLOCKS.contains(pos)) {
                return true;
            }

            for(class_2338 position : HammerItem.getBlocksToBeDestroyed(1, pos, serverPlayer)) {
                if(pos == position || !hammer.method_58405(mainHandItem, world.method_8320(position))) {
                    continue;
                }

                HARVESTED_BLOCKS.add(position);
                serverPlayer.field_13974.method_14266(position);
                HARVESTED_BLOCKS.remove(position);
            }
        }

        return true;
    }
}

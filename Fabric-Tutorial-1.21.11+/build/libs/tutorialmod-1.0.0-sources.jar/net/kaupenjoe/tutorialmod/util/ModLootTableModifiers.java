package net.kaupenjoe.tutorialmod.util;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.minecraft.class_141;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_39;
import net.minecraft.class_44;
import net.minecraft.class_55;
import net.minecraft.class_5662;
import net.minecraft.class_77;

public class ModLootTableModifiers {
    private static final class_2960 GRASS_BLOCK_ID
            = class_2960.method_60655("minecraft", "blocks/short_grass");
    private static final class_2960 CREEPER_ID
            = class_2960.method_60655("minecraft", "entities/creeper");

    public static void modifyLootTables() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registry) -> {
            if(GRASS_BLOCK_ID.equals(key.method_29177())) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.25f)) // Drops 25% of the time
                        .method_351(class_77.method_411(ModItems.CAULIFLOWER_SEEDS))
                        .apply(class_141.method_621(class_5662.method_32462(1.0f, 2.0f)).method_515());

                tableBuilder.pool(poolBuilder.method_355());
            }

            if(class_39.field_662.equals(key)) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(1.0f)) // Drops 100% of the time
                        .method_351(class_77.method_411(ModItems.CHISEL))
                        .apply(class_141.method_621(class_5662.method_32462(1.0f, 2.0f)).method_515());

                tableBuilder.pool(poolBuilder.method_355());
            }

            if(CREEPER_ID.equals(key.method_29177())) {
                class_55.class_56 poolBuilder = class_55.method_347()
                        .method_352(class_44.method_32448(1))
                        .method_356(class_219.method_932(0.75f)) // Drops 75% of the time
                        .method_351(class_77.method_411(ModItems.CAULIFLOWER))
                        .apply(class_141.method_621(class_5662.method_32462(1.0f, 2.0f)).method_515());

                tableBuilder.pool(poolBuilder.method_355());
            }
        });
    }
}

package net.kaupenjoe.tutorialmod.util;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModTags {
    public static class Blocks {
        public static final class_6862<class_2248> NEEDS_PINK_GARNET_TOOL = createTag("needs_pink_garnet_tool");
        public static final class_6862<class_2248> INCORRECT_FOR_PINK_GARNET_TOOL = createTag("incorrect_for_pink_garnet_tool");

        private static class_6862<class_2248> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(TutorialMod.MOD_ID, name));
        }
    }

    public static class Items {
        public static final class_6862<class_1792> TRANSFORMABLE_ITEMS = createTag("transformable_items");
        public static final class_6862<class_1792> PINK_GARNET_REPAIR = createTag("pink_garnet_repair");

        private static class_6862<class_1792> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(TutorialMod.MOD_ID, name));
        }
    }
}

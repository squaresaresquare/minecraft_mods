package net.kaupenjoe.tutorialmod.sound;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9793;

public class ModSounds {
    public static final class_3414 CHISEL_USE = registerSoundEvent("chisel_use");

    public static final class_3414 MAGIC_BLOCK_BREAK = registerSoundEvent("magic_block_break");
    public static final class_3414 MAGIC_BLOCK_STEP = registerSoundEvent("magic_block_step");
    public static final class_3414 MAGIC_BLOCK_PLACE = registerSoundEvent("magic_block_place");
    public static final class_3414 MAGIC_BLOCK_HIT = registerSoundEvent("magic_block_hit");
    public static final class_3414 MAGIC_BLOCK_FALL = registerSoundEvent("magic_block_fall");

    public static final class_2498 MAGIC_BLOCK_SOUNDS = new class_2498(1f, 1f,
            MAGIC_BLOCK_BREAK, MAGIC_BLOCK_STEP, MAGIC_BLOCK_PLACE, MAGIC_BLOCK_HIT, MAGIC_BLOCK_FALL);

    public static final class_3414 BAR_BRAWL = registerSoundEvent("bar_brawl");
    public static final class_5321<class_9793> BAR_BRAWL_KEY =
            class_5321.method_29179(class_7924.field_52176, class_2960.method_60655(TutorialMod.MOD_ID, "bar_brawl"));


    private static class_3414 registerSoundEvent(String name) {
        class_2960 id = class_2960.method_60655(TutorialMod.MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static void registerSounds() {
        TutorialMod.LOGGER.info("Registering Mod Sounds for " + TutorialMod.MOD_ID);
    }
}

package net.kaupenjoe.tutorialmod;

import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.fabricmc.fabric.api.registry.*;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.kaupenjoe.tutorialmod.block.entity.ModBlockEntities;
import net.kaupenjoe.tutorialmod.component.ModDataComponentTypes;
import net.kaupenjoe.tutorialmod.effect.ModEffects;
import net.kaupenjoe.tutorialmod.enchantment.ModEnchantmentEffects;
import net.kaupenjoe.tutorialmod.enchantment.ModEnchantments;
import net.kaupenjoe.tutorialmod.entity.ModEntities;
import net.kaupenjoe.tutorialmod.entity.custom.MantisEntity;
import net.kaupenjoe.tutorialmod.item.ModItemGroups;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.kaupenjoe.tutorialmod.particle.ModParticles;
import net.kaupenjoe.tutorialmod.potion.ModPotions;
import net.kaupenjoe.tutorialmod.recipe.ModRecipes;
import net.kaupenjoe.tutorialmod.screen.ModScreenHandlers;
import net.kaupenjoe.tutorialmod.sound.ModSounds;
import net.kaupenjoe.tutorialmod.util.HammerUsageEvent;
import net.kaupenjoe.tutorialmod.util.ModLootTableModifiers;
import net.kaupenjoe.tutorialmod.villager.ModVillagers;
import net.kaupenjoe.tutorialmod.world.gen.ModWorldGeneration;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1472;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1847;
import net.minecraft.class_1914;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3852;
import net.minecraft.class_9306;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Very important comment
public class TutorialMod implements ModInitializer {
	public static final String MOD_ID = "tutorialmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ModItemGroups.registerItemGroups();

		ModItems.registerModItems();
		ModBlocks.registerModBlocks();

		ModDataComponentTypes.registerDataComponentTypes();
		ModSounds.registerSounds();

		ModEffects.registerEffects();
		ModPotions.registerPotions();

		ModEnchantmentEffects.registerEnchantmentEffects();
		ModWorldGeneration.generateModWorldGen();

		ModEntities.registerModEntities();
		ModVillagers.registerVillagers();

		ModParticles.registerParticles();
		ModLootTableModifiers.modifyLootTables();

		ModBlockEntities.registerBlockEntities();
		ModScreenHandlers.registerScreenHandlers();

		ModRecipes.registerRecipes();

		FuelRegistryEvents.BUILD.register((builder, context) -> {
			builder.method_61762(ModItems.STARLIGHT_ASHES, 600);
		});

		PlayerBlockBreakEvents.BEFORE.register(new HammerUsageEvent());
		AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
			if(entity instanceof class_1472 sheepEntity) {
				if(player.method_6047().method_7909() == class_1802.field_8056) {
					player.method_7353(class_2561.method_43470("The Player just hit a sheep with an END ROD! YOU SICK FRICK!"), false);
					player.method_6047().method_7934(1);
					sheepEntity.method_6092(new class_1293(class_1294.field_5899, 600, 6));
				}

				return class_1269.field_5811;
			}

            return class_1269.field_5811;
        });

		FabricBrewingRecipeRegistryBuilder.BUILD.register(builder -> {
			builder.method_59705(class_1847.field_8999, class_1802.field_8777, ModPotions.SLIMEY_POTION);
		});

		CompostingChanceRegistry.INSTANCE.add(ModItems.CAULIFLOWER, 0.5f);
		CompostingChanceRegistry.INSTANCE.add(ModItems.CAULIFLOWER_SEEDS, 0.25f);
		CompostingChanceRegistry.INSTANCE.add(ModItems.HONEY_BERRIES, 0.15f);


		StrippableBlockRegistry.register(ModBlocks.DRIFTWOOD_LOG, ModBlocks.STRIPPED_DRIFTWOOD_LOG);
		StrippableBlockRegistry.register(ModBlocks.DRIFTWOOD_WOOD, ModBlocks.STRIPPED_DRIFTWOOD_WOOD);

		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.DRIFTWOOD_LOG, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.DRIFTWOOD_WOOD, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.STRIPPED_DRIFTWOOD_LOG, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.STRIPPED_DRIFTWOOD_WOOD, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.DRIFTWOOD_PLANKS, 5, 20);
		FlammableBlockRegistry.getDefaultInstance().add(ModBlocks.DRIFTWOOD_LEAVES, 30, 60);

		FabricDefaultAttributeRegistry.register(ModEntities.MANTIS, MantisEntity.createAttributes());

		TradeOfferHelper.registerVillagerOffers(class_3852.field_17056, 1, factories -> {
			factories.add((world,entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 3),
					new class_1799(ModItems.CAULIFLOWER, 8), 7, 2, 0.04f));

			factories.add((world,entity, random) -> new class_1914(
					new class_9306(class_1802.field_8477, 9),
					new class_1799(ModItems.CAULIFLOWER_SEEDS, 2), 3, 4, 0.04f));
		});

		TradeOfferHelper.registerVillagerOffers(class_3852.field_17056, 2, factories -> {
			factories.add((world,entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 12),
					new class_1799(ModItems.HONEY_BERRIES, 5), 4, 7, 0.04f));
		});

		TradeOfferHelper.registerVillagerOffers(ModVillagers.KAPUENGER_KEY, 1, factories -> {
			factories.add((world,entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 10),
					new class_1799(ModItems.CHISEL, 1), 4, 7, 0.04f));

			factories.add((world,entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 16),
					new class_1799(ModItems.RAW_PINK_GARNET, 1), 4, 7, 0.04f));
		});

		TradeOfferHelper.registerVillagerOffers(ModVillagers.KAPUENGER_KEY, 2, factories -> {
			factories.add((world,entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 10),
					new class_1799(ModItems.CHISEL, 1), 4, 7, 0.04f));

			factories.add((world,entity, random) -> new class_1914(
					new class_9306(ModItems.PINK_GARNET, 16),
					new class_1799(ModItems.TOMAHAWK, 1), 3, 12, 0.09f));
		});

		TradeOfferHelper.registerWanderingTraderOffers(factories -> {
			factories.addAll(class_2960.method_60655(TutorialMod.MOD_ID, "emerald_for_chisel"), (world, entity, random) -> new class_1914(
					new class_9306(class_1802.field_8687, 10),
					new class_1799(ModItems.CHISEL, 1), 4, 7, 0.04f));

			factories.addAll(class_2960.method_60655(TutorialMod.MOD_ID, "garnet_tomahawk"), (world, entity, random) -> new class_1914(
					new class_9306(ModItems.PINK_GARNET, 16),
					new class_1799(ModItems.TOMAHAWK, 1), 3, 12, 0.09f));
		});
	}
}
package net.kaupenjoe.tutorialmod.recipe;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public class ModRecipes {
    public static final class_1865<GrowthChamberRecipe> GROWTH_CHAMBER_SERIALIZER = class_2378.method_10230(
            class_7923.field_41189, class_2960.method_60655(TutorialMod.MOD_ID, "growth_chamber"),
                    new GrowthChamberRecipe.Serializer());
    public static final class_3956<GrowthChamberRecipe> GROWTH_CHAMBER_TYPE = class_2378.method_10230(
            class_7923.field_41188, class_2960.method_60655(TutorialMod.MOD_ID, "growth_chamber"), new class_3956<GrowthChamberRecipe>() {
                @Override
                public String toString() {
                    return "growth_chamber";
                }
            });

    public static void registerRecipes() {
        TutorialMod.LOGGER.info("Registering Custom Recipes for " + TutorialMod.MOD_ID);
    }
}

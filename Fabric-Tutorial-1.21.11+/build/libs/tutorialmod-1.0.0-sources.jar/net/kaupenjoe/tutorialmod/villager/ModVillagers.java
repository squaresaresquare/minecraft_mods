package net.kaupenjoe.tutorialmod.villager;

import com.google.common.collect.ImmutableSet;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3852;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModVillagers {
    public static final class_5321<class_4158> KAUPEN_POI_KEY = registerPoiKey("kaupen_poi");
    public static final class_4158 KAUPEN_POI = registerPOI("kaupen_poi", ModBlocks.CHAIR);

    public static final class_5321<class_3852> KAPUENGER_KEY =
            class_5321.method_29179(class_7924.field_41234, class_2960.method_60655(TutorialMod.MOD_ID, "kaupenger"));
    public static final class_3852 KAUPENGER = registerProfession("kaupenger", KAUPEN_POI_KEY);
    

    private static class_3852 registerProfession(String name, class_5321<class_4158> type) {
        return class_2378.method_10230(class_7923.field_41195, class_2960.method_60655(TutorialMod.MOD_ID, name),
                new class_3852(class_2561.method_43470("Kaupenger"), entry -> entry.method_40225(type), entry -> entry.method_40225(type),
                        ImmutableSet.of(), ImmutableSet.of(), class_3417.field_20677));
    }

    private static class_4158 registerPOI(String name, class_2248 block) {
        return PointOfInterestHelper.register(class_2960.method_60655(TutorialMod.MOD_ID, name),
                1, 1, block);
    }

    private static class_5321<class_4158> registerPoiKey(String name) {
        return class_5321.method_29179(class_7924.field_41212, class_2960.method_60655(TutorialMod.MOD_ID, name));
    }

    public static void registerVillagers() {
        TutorialMod.LOGGER.info("Registering Villagers for " + TutorialMod.MOD_ID);
    }
}

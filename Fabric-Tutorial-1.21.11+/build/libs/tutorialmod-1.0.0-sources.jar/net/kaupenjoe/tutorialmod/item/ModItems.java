package net.kaupenjoe.tutorialmod.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.kaupenjoe.tutorialmod.entity.ModEntities;
import net.kaupenjoe.tutorialmod.item.custom.ChiselItem;
import net.kaupenjoe.tutorialmod.item.custom.HammerItem;
import net.kaupenjoe.tutorialmod.item.custom.ModArmorItem;
import net.kaupenjoe.tutorialmod.item.custom.TomahawkItem;
import net.kaupenjoe.tutorialmod.sound.ModSounds;
import net.minecraft.class_10712;
import net.minecraft.class_1743;
import net.minecraft.class_1747;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1821;
import net.minecraft.class_1826;
import net.minecraft.class_1836;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8051;
import net.minecraft.class_8052;
import net.minecraft.item.*;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

public class ModItems {
    public static final class_1792 PINK_GARNET = registerItem("pink_garnet", class_1792::new);
    public static final class_1792 RAW_PINK_GARNET = registerItem("raw_pink_garnet", class_1792::new);

    public static final class_1792 CHISEL = registerItem("chisel", setting -> new ChiselItem(setting.method_7895(32)));
    public static final class_1792 CAULIFLOWER = registerItem("cauliflower", setting -> new class_1792(setting
            .method_62833(ModFoodComponents.CAULIFLOWER, ModFoodComponents.CAULIFLOWER_EFFECT)) {
        @Override
        public void method_67187(class_1799 stack, class_1792.class_9635 context, class_10712 displayComponent, Consumer<class_2561> textConsumer, class_1836 type) {
            textConsumer.accept(class_2561.method_43471("tooltip.tutorialmod.cauliflower.tooltip"));
            super.method_67187(stack, context, displayComponent, textConsumer, type);
        }
    });

    public static final class_1792 STARLIGHT_ASHES = registerItem("starlight_ashes", class_1792::new);

    public static final class_1792 PINK_GARNET_SWORD = registerItem("pink_garnet_sword",
            setting -> new class_1792(setting.method_66333(ModToolMaterials.PINK_GARNET, 3, -2.4f)));
    public static final class_1792 PINK_GARNET_PICKAXE = registerItem("pink_garnet_pickaxe",
            setting -> new class_1792(setting.method_66330(ModToolMaterials.PINK_GARNET, 1, -2.8f)));
    public static final class_1792 PINK_GARNET_SHOVEL = registerItem("pink_garnet_shovel",
            setting -> new class_1821(ModToolMaterials.PINK_GARNET, 1.5f, -3.0f, setting));
    public static final class_1792 PINK_GARNET_AXE = registerItem("pink_garnet_axe",
            setting -> new class_1743(ModToolMaterials.PINK_GARNET, 6, -3.2f, setting));
    public static final class_1792 PINK_GARNET_HOE = registerItem("pink_garnet_hoe",
            setting -> new class_1794(ModToolMaterials.PINK_GARNET, 0, -3f, setting));

    public static final class_1792 PINK_GARNET_HAMMER = registerItem("pink_garnet_hammer",
            setting -> new HammerItem(ModToolMaterials.PINK_GARNET, 7, -3.4f, setting));

    public static final class_1792 PINK_GARNET_HELMET = registerItem("pink_garnet_helmet",
            setting -> new ModArmorItem(setting.method_66332(ModArmorMaterials.PINK_GARNET_ARMOR_MATERIAL, class_8051.field_41934)));
    public static final class_1792 PINK_GARNET_CHESTPLATE = registerItem("pink_garnet_chestplate",
            setting -> new class_1792(setting.method_66332(ModArmorMaterials.PINK_GARNET_ARMOR_MATERIAL, class_8051.field_41935)));
    public static final class_1792 PINK_GARNET_LEGGINGS = registerItem("pink_garnet_leggings",
            setting -> new class_1792(setting.method_66332(ModArmorMaterials.PINK_GARNET_ARMOR_MATERIAL, class_8051.field_41936)));
    public static final class_1792 PINK_GARNET_BOOTS = registerItem("pink_garnet_boots",
            setting -> new class_1792(setting.method_66332(ModArmorMaterials.PINK_GARNET_ARMOR_MATERIAL, class_8051.field_41937)));

    public static final class_1792 PINK_GARNET_HORSE_ARMOR = registerItem("pink_garnet_horse_armor",
            setting -> new class_1792(setting.method_67191(ModArmorMaterials.PINK_GARNET_ARMOR_MATERIAL).method_7889(1)));
    public static final class_1792 KAUPEN_SMITHING_TEMPLATE = registerItem("kaupen_armor_trim_smithing_template",
            class_8052::method_48418);

    public static final class_1792 KAUPEN_BOW = registerItem("kaupen_bow",
            setting -> new class_1753(setting.method_7895(500)));

    public static final class_1792 BAR_BRAWL_MUSIC_DISC = registerItem("bar_brawl_music_disc",
            setting -> new class_1792(setting.method_60745(ModSounds.BAR_BRAWL_KEY).method_7889(1)));

    public static final class_1792 CAULIFLOWER_SEEDS = registerItem("cauliflower_seeds",
            setting -> new class_1747(ModBlocks.CAULIFLOWER_CROP, setting));

    public static final class_1792 HONEY_BERRIES = registerItem("honey_berries",
            setting -> new class_1747(ModBlocks.HONEY_BERRY_BUSH, setting.method_19265(ModFoodComponents.HONEY_BERRIES)));

    public static final class_1792 MANTIS_SPAWN_EGG = registerItem("mantis_spawn_egg",
            setting -> new class_1826(setting.method_72499(ModEntities.MANTIS)));

    public static final class_1792 TOMAHAWK = registerItem("tomahawk",
            setting -> new TomahawkItem(setting.method_7889(16)));

    public static final class_1792 SPECTRE_STAFF = registerItem("spectre_staff",
            setting -> new class_1792(setting.method_7889(1)));


    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> function) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TutorialMod.MOD_ID, name),
                function.apply(new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(TutorialMod.MOD_ID, name)))));
    }
    public static void registerModItems() {
        TutorialMod.LOGGER.info("Registering Mod Items for " + TutorialMod.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> {
            entries.method_45421(PINK_GARNET);
            entries.method_45421(RAW_PINK_GARNET);
        });
    }
}
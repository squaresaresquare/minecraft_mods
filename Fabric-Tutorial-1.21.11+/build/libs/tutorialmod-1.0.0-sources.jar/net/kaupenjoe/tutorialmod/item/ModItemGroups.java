package net.kaupenjoe.tutorialmod.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroups {
    public static final class_1761 PINK_GARNET_ITEMS_GROUP = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_60655(TutorialMod.MOD_ID, "pink_garnet_items"),
            FabricItemGroup.builder().method_47320(() -> new class_1799(ModItems.PINK_GARNET))
                    .method_47321(class_2561.method_43471("itemgroup.tutorialmod.pink_garnet_items"))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModItems.PINK_GARNET);
                        entries.method_45421(ModItems.RAW_PINK_GARNET);

                        entries.method_45421(ModItems.CHISEL);
                        entries.method_45421(ModItems.CAULIFLOWER);

                        entries.method_45421(ModItems.STARLIGHT_ASHES);

                        entries.method_45421(ModItems.PINK_GARNET_SWORD);
                        entries.method_45421(ModItems.PINK_GARNET_PICKAXE);
                        entries.method_45421(ModItems.PINK_GARNET_SHOVEL);
                        entries.method_45421(ModItems.PINK_GARNET_AXE);
                        entries.method_45421(ModItems.PINK_GARNET_HOE);

                        entries.method_45421(ModItems.PINK_GARNET_HAMMER);

                        entries.method_45421(ModItems.PINK_GARNET_HELMET);
                        entries.method_45421(ModItems.PINK_GARNET_CHESTPLATE);
                        entries.method_45421(ModItems.PINK_GARNET_LEGGINGS);
                        entries.method_45421(ModItems.PINK_GARNET_BOOTS);

                        entries.method_45421(ModItems.PINK_GARNET_HORSE_ARMOR);
                        entries.method_45421(ModItems.KAUPEN_SMITHING_TEMPLATE);

                        entries.method_45421(ModItems.KAUPEN_BOW);
                        entries.method_45421(ModItems.BAR_BRAWL_MUSIC_DISC);

                        entries.method_45421(ModItems.CAULIFLOWER_SEEDS);
                        entries.method_45421(ModItems.HONEY_BERRIES);

                        entries.method_45421(ModItems.TOMAHAWK);
                        entries.method_45421(ModItems.SPECTRE_STAFF);

                        entries.method_45421(ModItems.MANTIS_SPAWN_EGG);

                    }).method_47324());

    public static final class_1761 PINK_GARNET_BLOCKS_GROUP = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_60655(TutorialMod.MOD_ID, "pink_garnet_blocks"),
            FabricItemGroup.builder().method_47320(() -> new class_1799(ModBlocks.PINK_GARNET_BLOCK))
                    .method_47321(class_2561.method_43471("itemgroup.tutorialmod.pink_garnet_blocks"))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModBlocks.PINK_GARNET_BLOCK);
                        entries.method_45421(ModBlocks.RAW_PINK_GARNET_BLOCK);

                        entries.method_45421(ModBlocks.PINK_GARNET_ORE);
                        entries.method_45421(ModBlocks.PINK_GARNET_DEEPSLATE_ORE);

                        entries.method_45421(ModBlocks.MAGIC_BLOCK);

                        entries.method_45421(ModBlocks.PINK_GARNET_STAIRS);
                        entries.method_45421(ModBlocks.PINK_GARNET_SLAB);

                        entries.method_45421(ModBlocks.PINK_GARNET_BUTTON);
                        entries.method_45421(ModBlocks.PINK_GARNET_PRESSURE_PLATE);

                        entries.method_45421(ModBlocks.PINK_GARNET_FENCE);
                        entries.method_45421(ModBlocks.PINK_GARNET_FENCE_GATE);
                        entries.method_45421(ModBlocks.PINK_GARNET_WALL);

                        entries.method_45421(ModBlocks.PINK_GARNET_DOOR);
                        entries.method_45421(ModBlocks.PINK_GARNET_TRAPDOOR);

                        entries.method_45421(ModBlocks.PINK_GARNET_LAMP);

                        entries.method_45421(ModBlocks.DRIFTWOOD_LOG);
                        entries.method_45421(ModBlocks.DRIFTWOOD_WOOD);
                        entries.method_45421(ModBlocks.STRIPPED_DRIFTWOOD_LOG);
                        entries.method_45421(ModBlocks.STRIPPED_DRIFTWOOD_WOOD);

                        entries.method_45421(ModBlocks.DRIFTWOOD_PLANKS);
                        entries.method_45421(ModBlocks.DRIFTWOOD_LEAVES);

                        entries.method_45421(ModBlocks.DRIFTWOOD_SAPLING);

                        entries.method_45421(ModBlocks.CHAIR);
                        entries.method_45421(ModBlocks.PEDESTAL);
                        entries.method_45421(ModBlocks.GROWTH_CHAMBER);


                    }).method_47324());


    public static void registerItemGroups() {
        TutorialMod.LOGGER.info("Registering Item Groups for " + TutorialMod.MOD_ID);
    }
}

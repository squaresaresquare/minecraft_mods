package net.kaupenjoe.tutorialmod.item.custom;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_9886;

public class HammerItem extends class_1792 {
    public HammerItem(class_9886 material, float attackDamage, float attackSpeed, class_1793 settings) {
        super(settings.method_66330(material, attackDamage, attackSpeed));
    }

    public static List<class_2338> getBlocksToBeDestroyed(int range, class_2338 initalBlockPos, class_3222 player) {
        List<class_2338> positions = new ArrayList<>();
        class_239 hit = player.method_5745(20, 0, false);
        if (hit.method_17783() == class_239.class_240.field_1332) {
            class_3965 blockHit = (class_3965) hit;

            if(blockHit.method_17780() == class_2350.field_11033 || blockHit.method_17780() == class_2350.field_11036) {
                for(int x = -range; x <= range; x++) {
                    for(int y = -range; y <= range; y++) {
                        positions.add(new class_2338(initalBlockPos.method_10263() + x, initalBlockPos.method_10264(), initalBlockPos.method_10260() + y));
                    }
                }
            }

            if(blockHit.method_17780() == class_2350.field_11043 || blockHit.method_17780() == class_2350.field_11035) {
                for(int x = -range; x <= range; x++) {
                    for(int y = -range; y <= range; y++) {
                        positions.add(new class_2338(initalBlockPos.method_10263() + x, initalBlockPos.method_10264() + y, initalBlockPos.method_10260()));
                    }
                }
            }

            if(blockHit.method_17780() == class_2350.field_11034 || blockHit.method_17780() == class_2350.field_11039) {
                for(int x = -range; x <= range; x++) {
                    for(int y = -range; y <= range; y++) {
                        positions.add(new class_2338(initalBlockPos.method_10263(), initalBlockPos.method_10264() + y, initalBlockPos.method_10260() + x));
                    }
                }
            }
        }

        return positions;
    }
}

package net.kaupenjoe.tutorialmod.item;

import net.kaupenjoe.tutorialmod.util.ModTags;
import net.minecraft.class_9886;

public class ModToolMaterials {
    public static class_9886 PINK_GARNET = new class_9886(ModTags.Blocks.INCORRECT_FOR_PINK_GARNET_TOOL,
            1200, 5.0F, 4.0F, 22, ModTags.Items.PINK_GARNET_REPAIR);
}

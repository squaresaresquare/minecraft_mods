package net.kaupenjoe.tutorialmod.item.custom;

import com.google.common.collect.ImmutableMap;
import net.kaupenjoe.tutorialmod.item.ModArmorMaterials;
import net.minecraft.class_10192;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;

public class ModArmorItem extends class_1792 {
    private static final Map<class_1741, List<class_1293>> MATERIAL_TO_EFFECT_MAP =
            (new ImmutableMap.Builder<class_1741, List<class_1293>>())
                    .put(ModArmorMaterials.PINK_GARNET_ARMOR_MATERIAL,
                            List.of(new class_1293(class_1294.field_5917, 400, 2, false, false),
                                    new class_1293(class_1294.field_5913, 400, 1, false, false))).build();

    public ModArmorItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_7888(class_1799 stack, class_3218 world, class_1297 entity, @Nullable class_1304 slot) {
        if(!world.method_8608()) {
            if(entity instanceof class_1657 player) {
                if(hasFullSuitOfArmorOn(player)) {
                    evaluateArmorEffects(player);
                }
            }
        }

        super.method_7888(stack, world, entity, slot);
    }

    private void evaluateArmorEffects(class_1657 player) {
        for (Map.Entry<class_1741, List<class_1293>> entry : MATERIAL_TO_EFFECT_MAP.entrySet()) {
            class_1741 mapArmorMaterial = entry.getKey();
            List<class_1293> mapStatusEffects = entry.getValue();

            if(hasCorrectArmorOn(mapArmorMaterial, player)) {
                addStatusEffectForMaterial(player, mapArmorMaterial, mapStatusEffects);
            }
        }
    }

    private void addStatusEffectForMaterial(class_1657 player, class_1741 mapArmorMaterial, List<class_1293> mapStatusEffect) {
        boolean hasPlayerEffect = mapStatusEffect.stream().allMatch(statusEffectInstance -> player.method_6059(statusEffectInstance.method_5579()));

        if(!hasPlayerEffect) {
            for (class_1293 instance : mapStatusEffect) {
                player.method_6092(new class_1293(instance.method_5579(),
                        instance.method_5584(), instance.method_5578(), instance.method_5591(), instance.method_5581()));
            }
        }
    }

    private boolean hasFullSuitOfArmorOn(class_1657 player) {
        class_1799 boots = player.method_6118(class_1304.field_6166);
        class_1799 leggings = player.method_6118(class_1304.field_6172);
        class_1799 chestplate = player.method_6118(class_1304.field_6174);
        class_1799 helmet = player.method_6118(class_1304.field_6169);

        return !helmet.method_7960() && !chestplate.method_7960()
                && !leggings.method_7960() && !boots.method_7960();
    }

    private boolean hasCorrectArmorOn(class_1741 material, class_1657 player) {
        class_1799 boots = player.method_6118(class_1304.field_6166);
        class_1799 leggings = player.method_6118(class_1304.field_6172);
        class_1799 chestplate = player.method_6118(class_1304.field_6174);
        class_1799 helmet = player.method_6118(class_1304.field_6169);

        class_10192 equippableComponentBoots = boots.method_57353().method_58694(class_9334.field_54196);
        class_10192 equippableComponentLeggings = leggings.method_57353().method_58694(class_9334.field_54196);
        class_10192 equippableComponentBreastplate = chestplate.method_57353().method_58694(class_9334.field_54196);
        class_10192 equippableComponentHelmet = helmet.method_57353().method_58694(class_9334.field_54196);

        return equippableComponentBoots.comp_3176().get().equals(material.comp_3168()) && equippableComponentLeggings.comp_3176().get().equals(material.comp_3168()) &&
                equippableComponentBreastplate.comp_3176().get().equals(material.comp_3168()) && equippableComponentHelmet.comp_3176().get().equals(material.comp_3168());
    }
}
package net.kaupenjoe.tutorialmod.item.custom;

import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.kaupenjoe.tutorialmod.component.ModDataComponentTypes;
import net.kaupenjoe.tutorialmod.particle.ModParticles;
import net.kaupenjoe.tutorialmod.sound.ModSounds;
import net.minecraft.class_10712;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class ChiselItem extends class_1792 {
    private static final Map<class_2248, class_2248> CHISEL_MAP =
            Map.of(
                    class_2246.field_10340, class_2246.field_10056,
                    class_2246.field_10471, class_2246.field_10462,
                    class_2246.field_10431, ModBlocks.PINK_GARNET_BLOCK,
                    class_2246.field_10205, class_2246.field_22108
            );

    public ChiselItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2248 clickedBlock = world.method_8320(context.method_8037()).method_26204();

        if(CHISEL_MAP.containsKey(clickedBlock)) {
            if(!world.method_8608()) {
                world.method_8501(context.method_8037(), CHISEL_MAP.get(clickedBlock).method_9564());

                context.method_8041().method_7956(1, ((class_3218) world), ((class_3222) context.method_8036()),
                        item -> context.method_8036().method_20235(item, class_1304.field_6173));

                world.method_45447(null, context.method_8037(), ModSounds.CHISEL_USE, class_3419.field_15245);

                ((class_3218) world).method_65096(new class_2388(class_2398.field_11217, clickedBlock.method_9564()),
                        context.method_8037().method_10263() + 0.5, context.method_8037().method_10264() + 1.0,
                        context.method_8037().method_10260() + 0.5, 5, 0, 0, 0, 1);

                ((class_3218) world).method_65096(class_2398.field_11240,
                        context.method_8037().method_10263() + 0.5, context.method_8037().method_10264() + 1.5,
                        context.method_8037().method_10260() + 0.5, 10, 0, 0, 0, 3);

                ((class_3218) world).method_65096(ModParticles.PINK_GARNET_PARTICLE,
                        context.method_8037().method_10263() + 0.5, context.method_8037().method_10264() + 1.0,
                        context.method_8037().method_10260() + 0.5, 8, 0, 0, 0, 2);



                context.method_8041().method_57379(ModDataComponentTypes.COORDINATES, context.method_8037());
            }
        }

        return class_1269.field_5812;
    }

    @Override
    public void method_67187(class_1799 stack, class_9635 context, class_10712 displayComponent, Consumer<class_2561> textConsumer, class_1836 type) {
        if(class_310.method_1551().method_74187()) {
            textConsumer.accept(class_2561.method_43471("tooltip.tutorialmod.chisel.shift_down"));
        } else {
            textConsumer.accept(class_2561.method_43471("tooltip.tutorialmod.chisel"));
        }

        if(stack.method_58694(ModDataComponentTypes.COORDINATES) != null) {
            textConsumer.accept(class_2561.method_43470("Last Block Changed at " + stack.method_58694(ModDataComponentTypes.COORDINATES)));
        }

        super.method_67187(stack, context, displayComponent, textConsumer, type);
    }

    int counter = 1;
    int chanceToAddLevitation = class_3532.method_15395(class_5819.method_43047(), 1, 5);

    @Override
    public void method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        if(counter <= chanceToAddLevitation) {
            target.method_37222(new class_1293(class_1294.field_5914, 50, 0), attacker);
            counter = 1;
        } else {
            counter++;
        }
    }
}

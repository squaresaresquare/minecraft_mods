package net.kaupenjoe.tutorialmod.item;

import net.minecraft.class_10124;
import net.minecraft.class_10128;
import net.minecraft.class_10132;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_4174;

public class ModFoodComponents {
    public static final class_4174 CAULIFLOWER = new class_4174.class_4175().method_19238(3).method_19237(0.25f).method_19242();

    public static final class_10124 CAULIFLOWER_EFFECT = class_10128.method_62858()
            .method_62854(new class_10132(new class_1293(class_1294.field_5914, 200), 0.15f)).method_62851();


    public static final class_4174 HONEY_BERRIES = new class_4174.class_4175().method_19238(2).method_19237(0.15f).method_19242();

}

package net.kaupenjoe.tutorialmod.item;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.util.ModTags;
import net.minecraft.class_10394;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_5321;
import net.minecraft.class_8051;
import java.util.EnumMap;

public class ModArmorMaterials {
    static class_5321<? extends class_2378<class_10394>> REGISTRY_KEY = class_5321.method_29180(class_2960.method_60656("equipment_asset"));
    public static final class_5321<class_10394> PINK_GARNET_KEY = class_5321.method_29179(REGISTRY_KEY, class_2960.method_60655(TutorialMod.MOD_ID, "pink_garnet"));

    public static final class_1741 PINK_GARNET_ARMOR_MATERIAL = new class_1741(500, class_156.method_654(new EnumMap<>(class_8051.class), map -> {
        map.put(class_8051.field_41937, 2);
        map.put(class_8051.field_41936, 4);
        map.put(class_8051.field_41935, 6);
        map.put(class_8051.field_41934, 2);
        map.put(class_8051.field_48838, 4);
    }), 20, class_3417.field_15103,0,0, ModTags.Items.PINK_GARNET_REPAIR, PINK_GARNET_KEY);
}

package net.kaupenjoe.tutorialmod.entity.client;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.entity.custom.TomahawkProjectileEntity;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class TomahawkProjectileRenderer extends class_897<TomahawkProjectileEntity, class_10017> {
    protected TomahawkProjectileModel model;

    public TomahawkProjectileRenderer(class_5617.class_5618 ctx) {
        super(ctx);
        this.model = new TomahawkProjectileModel(ctx.method_32167(TomahawkProjectileModel.TOMAHAWK));
    }

    @Override
    public void method_3936(class_10017 renderState, class_4587 matrices, class_11659 queue, class_12075 cameraState) {
        // matrices.push();
//
        // VertexConsumer vertexconsumer = ItemRenderer.getItemGlintConsumer(vertexConsumers,
        //         this.model.getLayer(Identifier.of(TutorialMod.MOD_ID, "textures/entity/tomahawk/tomahawk.png")), false, false);
        // this.model.render(matrices, vertexconsumer, light, OverlayTexture.DEFAULT_UV);
//
        // matrices.pop();

        super.method_3936(renderState, matrices, queue, cameraState);
    }

    @Override
    public class_10017 method_55269() {
        return new class_10017();
    }
}

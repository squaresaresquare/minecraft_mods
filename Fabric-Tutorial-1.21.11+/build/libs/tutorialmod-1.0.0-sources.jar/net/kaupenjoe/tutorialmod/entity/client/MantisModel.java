package net.kaupenjoe.tutorialmod.entity.client;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.entity.custom.MantisEntity;
import net.minecraft.class_11509;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class MantisModel extends class_583<MantisRenderState> {
    public static final class_5601 MANTIS = new class_5601(class_2960.method_60655(TutorialMod.MOD_ID, "mantis"), "main");
    private final class_630 root;
    private final class_630 mantis;
    private final class_630 head;

    private final class_11509 walkingAnimation;
    private final class_11509 idlingAnimation;


    public MantisModel(class_630 root) {
        super(root);
        this.field_54014 = root.method_32086("root");
        this.mantis = this.field_54014.method_32086("mantis");
        this.head = this.mantis.method_32086("head");

        this.walkingAnimation = MantisAnimations.ANIM_MANTIS_WALK.method_71979(root);
        this.idlingAnimation = MantisAnimations.ANIM_MANTIS_IDLE.method_71979(root);
    }

    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();
        class_5610 root = modelPartData.method_32117("root", class_5606.method_32108(), class_5603.method_32091(0.0F, 24.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

        class_5610 mantis = root.method_32117("mantis", class_5606.method_32108(), class_5603.method_32091(-0.5F, -3.0F, -28.0F, 0.3927F, 0.0F, 0.0F));

        class_5610 body = mantis.method_32117("body", class_5606.method_32108().method_32101(0, 0).method_32098(-2.5F, -1.0F, 8.75F, 5.0F, 2.0F, 25.0F, new class_5605(0.0F))
                .method_32101(0, 0).method_32098(-3.5F, -2.0F, -51.25F, 7.0F, 4.0F, 60.0F, new class_5605(0.0F)), class_5603.method_32092(0.0F, -12.0F, 26.25F));

        class_5610 head = mantis.method_32117("head", class_5606.method_32108().method_32101(31, 27).method_32098(-3.5F, -1.0F, 0.0F, 7.0F, 4.0F, 3.0F, new class_5605(0.0F))
                .method_32101(35, 20).method_32098(-2.5F, 3.0F, 0.0F, 5.0F, 2.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -13.0F, 60.0F, 0.3491F, 0.0F, 0.0F));

        class_5610 antenna1 = head.method_32117("antenna1", class_5606.method_32108().method_32101(56, 71).method_32098(0.0F, 0.0F, 0.0F, 0.0F, 3.0F, 20.0F, new class_5605(0.0F)), class_5603.method_32091(-1.5F, -1.0F, 3.0F, 0.4363F, 0.0F, 0.0F));

        class_5610 antenna2 = head.method_32117("antenna2", class_5606.method_32108().method_32101(56, 71).method_32098(0.0F, 0.0F, 0.0F, 0.0F, 3.0F, 20.0F, new class_5605(0.0F)), class_5603.method_32091(1.5F, -1.0F, 3.0F, 0.4363F, 0.0F, 0.0F));

        class_5610 mouth1 = head.method_32117("mouth1", class_5606.method_32108().method_32101(14, 0).method_32098(-2.0F, 0.0F, 0.0F, 2.0F, 2.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32092(2.5F, 5.0F, 1.0F));

        class_5610 mouth2 = head.method_32117("mouth2", class_5606.method_32108().method_32101(6, 0).method_32098(0.0F, 0.0F, 0.0F, 2.0F, 2.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32092(-2.5F, 5.0F, 1.0F));

        class_5610 wing1 = mantis.method_32117("wing1", class_5606.method_32108().method_32101(56, 0).method_32098(-3.5F, 0.0F, -60.0F, 7.0F, 0.0F, 60.0F, new class_5605(0.0F)), class_5603.method_32092(0.0F, -14.04F, 35.0F));

        class_5610 wing2 = mantis.method_32117("wing2", class_5606.method_32108().method_32101(56, 0).method_32096().method_32098(-3.5F, 0.0F, -60.0F, 7.0F, 0.0F, 60.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32092(0.0F, -14.03F, 35.0F));

        class_5610 wing3 = mantis.method_32117("wing3", class_5606.method_32108().method_32101(28, 0).method_32098(-3.5F, 0.0F, -60.0F, 7.0F, 0.0F, 60.0F, new class_5605(0.0F)), class_5603.method_32092(0.0F, -14.02F, 35.0F));

        class_5610 wing4 = mantis.method_32117("wing4", class_5606.method_32108().method_32101(28, 0).method_32096().method_32098(-3.5F, 0.0F, -60.0F, 7.0F, 0.0F, 60.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32092(0.0F, -14.01F, 35.0F));

        class_5610 arm1 = mantis.method_32117("arm1", class_5606.method_32108().method_32101(8, 0).method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 20.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32092(-2.5F, -11.0F, 51.0F));

        class_5610 arm1seg2 = arm1.method_32117("arm1seg2", class_5606.method_32108().method_32101(0, 64).method_32098(-1.5F, -1.5F, -2.0F, 3.0F, 3.0F, 25.0F, new class_5605(0.0F))
                .method_32101(31, 62).method_32098(0.0F, 1.5F, -2.0F, 0.0F, 6.0F, 20.0F, new class_5605(0.0F)), class_5603.method_32092(0.0F, 19.5F, 0.0F));

        class_5610 arm1seg3 = arm1seg2.method_32117("arm1seg3", class_5606.method_32108().method_32101(10, 27).method_32098(-0.5F, 0.0F, -0.5F, 1.0F, 20.0F, 1.0F, new class_5605(0.0F))
                .method_32101(0, 24).method_32098(0.0F, 0.0F, -3.5F, 0.0F, 20.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32092(0.0F, 0.5F, 21.5F));

        class_5610 arm2 = mantis.method_32117("arm2", class_5606.method_32108().method_32101(8, 0).method_32096().method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 20.0F, 2.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32092(2.5F, -11.0F, 51.0F));

        class_5610 arm2seg2 = arm2.method_32117("arm2seg2", class_5606.method_32108().method_32101(0, 64).method_32096().method_32098(-1.5F, -1.5F, -2.0F, 3.0F, 3.0F, 25.0F, new class_5605(0.0F)).method_32106(false)
                .method_32101(31, 62).method_32098(0.0F, 1.5F, -2.0F, 0.0F, 6.0F, 20.0F, new class_5605(0.0F)), class_5603.method_32092(0.0F, 19.5F, 0.0F));

        class_5610 arm2seg3 = arm2seg2.method_32117("arm2seg3", class_5606.method_32108().method_32101(10, 27).method_32096().method_32098(-0.5F, 0.0F, -0.5F, 1.0F, 20.0F, 1.0F, new class_5605(0.0F)).method_32106(false)
                .method_32101(0, 25).method_32098(0.0F, 0.0F, -3.5F, 0.0F, 20.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32092(0.0F, 0.5F, 21.5F));

        class_5610 frontLeg1 = mantis.method_32117("frontLeg1", class_5606.method_32108().method_32101(39, 34).method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 8.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-3.5F, -10.0F, 27.0F, -0.7854F, 0.0F, 0.0F));

        class_5610 frontLeg1seg2 = frontLeg1.method_32117("frontLeg1seg2", class_5606.method_32108().method_32101(54, 94).method_32098(-0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 18.0F, new class_5605(0.0F))
                .method_32101(36, 76).method_32098(0.0F, 0.5F, 0.0F, 0.0F, 5.0F, 18.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 5.5F, 0.0F, 0.3927F, -0.4363F, 0.0F));

        class_5610 frontLeg1seg3 = frontLeg1seg2.method_32117("frontLeg1seg3", class_5606.method_32108().method_32101(18, 27).method_32098(-0.5F, 0.0F, -0.5F, 1.0F, 18.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.5F, 17.5F, 0.2618F, 0.0F, 0.0F));

        class_5610 frontLeg2 = mantis.method_32117("frontLeg2", class_5606.method_32108().method_32101(39, 34).method_32096().method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 8.0F, 2.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32091(3.5F, -10.0F, 27.0F, -0.7854F, 0.0F, 0.0F));

        class_5610 frontLeg2seg2 = frontLeg2.method_32117("frontLeg2seg2", class_5606.method_32108().method_32101(54, 94).method_32096().method_32098(-0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 18.0F, new class_5605(0.0F)).method_32106(false)
                .method_32101(36, 76).method_32098(0.0F, 0.5F, 0.0F, 0.0F, 5.0F, 18.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 5.5F, 0.0F, 0.3927F, 0.4363F, 0.0F));

        class_5610 frontLeg2seg3 = frontLeg2seg2.method_32117("frontLeg2seg3", class_5606.method_32108().method_32101(18, 27).method_32096().method_32098(-0.5F, 0.0F, -0.5F, 1.0F, 18.0F, 1.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32091(0.0F, 0.5F, 17.5F, 0.2618F, 0.0F, 0.0F));

        class_5610 backLeg1 = mantis.method_32117("backLeg1", class_5606.method_32108().method_32101(35, 0).method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 8.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-3.5F, -10.0F, 20.0F, -0.7854F, 0.0F, 0.0F));

        class_5610 backLeg1seg2 = backLeg1.method_32117("backLeg1seg2", class_5606.method_32108().method_32101(83, 65).method_32098(-0.5F, -0.5F, -25.0F, 1.0F, 1.0F, 25.0F, new class_5605(0.0F))
                .method_32101(31, 45).method_32098(0.0F, 0.5F, -25.0F, 0.0F, 6.0F, 25.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 5.5F, 0.0F, 0.0F, 0.4363F, 0.5236F));

        class_5610 backLeg1seg3 = backLeg1seg2.method_32117("backLeg1seg3", class_5606.method_32108().method_32101(4, 97).method_32098(-0.5F, 0.0F, -0.5F, 1.0F, 35.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32092(0.0F, 0.5F, -24.5F));

        class_5610 backLeg2 = mantis.method_32117("backLeg2", class_5606.method_32108().method_32101(35, 0).method_32096().method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 8.0F, 2.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32091(3.5F, -10.0F, 20.0F, -0.7854F, 0.0F, 0.0F));

        class_5610 backLeg2seg2 = backLeg2.method_32117("backLeg2seg2", class_5606.method_32108().method_32101(83, 65).method_32096().method_32098(-0.5F, -0.5F, -25.0F, 1.0F, 1.0F, 25.0F, new class_5605(0.0F)).method_32106(false)
                .method_32101(31, 45).method_32098(0.0F, 0.5F, -25.0F, 0.0F, 6.0F, 25.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 5.5F, 0.0F, 0.0F, -0.4363F, -0.5236F));

        class_5610 backLeg2seg3 = backLeg2seg2.method_32117("backLeg2seg3", class_5606.method_32108().method_32101(4, 97).method_32096().method_32098(-0.5F, 0.0F, -0.5F, 1.0F, 35.0F, 1.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32092(0.0F, 0.5F, -24.5F));
        return class_5607.method_32110(modelData, 256, 256);
    }

    @Override
    public void setAngles(MantisRenderState state) {
        super.method_2819(state);
        this.setHeadAngles(state.field_53447, state.field_53448);

        this.walkingAnimation.method_71981(state.field_53450, state.field_53451, 2f, 2.5f);
        this.idlingAnimation.method_71986(state.idleAnimationState, state.field_53328, 1f);
    }

    private void setHeadAngles(float headYaw, float headPitch) {
        headYaw = class_3532.method_15363(headYaw, -30.0F, 30.0F);
        headPitch = class_3532.method_15363(headPitch, -25.0F, 45.0F);

        this.head.field_3675 = headYaw * 0.017453292F;
        this.head.field_3654 = headPitch * 0.017453292F;
    }
}

package net.kaupenjoe.tutorialmod.entity;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.entity.custom.ChairEntity;
import net.kaupenjoe.tutorialmod.entity.custom.MantisEntity;
import net.kaupenjoe.tutorialmod.entity.custom.TomahawkProjectileEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModEntities {
    private static final class_5321<class_1299<?>> MANTIS_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TutorialMod.MOD_ID, "mantis"));
    private static final class_5321<class_1299<?>> TOMAHAWK_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TutorialMod.MOD_ID, "tomahawk"));
    private static final class_5321<class_1299<?>> CHAIR_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TutorialMod.MOD_ID, "chair_entity"));


    public static final class_1299<MantisEntity> MANTIS = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TutorialMod.MOD_ID, "mantis"),
            class_1299.class_1300.method_5903(MantisEntity::new, class_1311.field_6294)
                    .method_17687(1f, 2.5f).method_5905(MANTIS_KEY));

    public static final class_1299<TomahawkProjectileEntity> TOMAHAWK = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TutorialMod.MOD_ID, "tomahawk"),
            class_1299.class_1300.<TomahawkProjectileEntity>method_5903(TomahawkProjectileEntity::new, class_1311.field_17715)
                    .method_17687(0.5f, 1.15f).method_5905(TOMAHAWK_KEY));

    public static final class_1299<ChairEntity> CHAIR = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TutorialMod.MOD_ID, "chair_entity"),
            class_1299.class_1300.method_5903(ChairEntity::new, class_1311.field_17715)
                    .method_17687(0.5f, 0.5f).method_5905(CHAIR_KEY));



    public static void registerModEntities() {
        TutorialMod.LOGGER.info("Registering Mod Entities for " + TutorialMod.MOD_ID);
    }
}

package net.kaupenjoe.tutorialmod.entity.client;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.entity.custom.TomahawkProjectileEntity;
import net.minecraft.class_10017;
import net.minecraft.class_2960;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class TomahawkProjectileModel extends class_583<class_10017> {
    public static final class_5601 TOMAHAWK = new class_5601(class_2960.method_60655(TutorialMod.MOD_ID, "tomahawk"), "main");
    private final class_630 tomahawk;

    public TomahawkProjectileModel(class_630 root) {
        super(root);
        this.tomahawk = root.method_32086("tomahawk");
    }

    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();
        class_5610 tomahawk = modelPartData.method_32117("tomahawk", class_5606.method_32108(), class_5603.method_32092(0.0F, 16.5F, 0.0F));

        class_5610 cube_r1 = tomahawk.method_32117("cube_r1", class_5606.method_32108().method_32101(8, 7).method_32098(1.5F, 2.5F, -0.5F, 1.0F, 1.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -7.0F, -4.0F, 0.0F, -1.5708F, 0.0F));

        class_5610 cube_r2 = tomahawk.method_32117("cube_r2", class_5606.method_32108().method_32101(7, 9).method_32098(0.5F, -1.5F, -0.5F, 2.0F, 5.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -7.0F, -5.0F, 0.0F, -1.5708F, 0.0F));

        class_5610 cube_r3 = tomahawk.method_32117("cube_r3", class_5606.method_32108().method_32101(3, 10).method_32098(-2.5F, -1.5F, -0.5F, 1.0F, 4.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -7.0F, 5.0F, 0.0F, -1.5708F, 0.0F));

        class_5610 cube_r4 = tomahawk.method_32117("cube_r4", class_5606.method_32108().method_32101(1, 4).method_32098(-2.5F, -1.5F, 0.0F, 5.0F, 3.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -7.0F, 0.0F, 0.0F, -1.5708F, 0.0F));

        class_5610 cube_r5 = tomahawk.method_32117("cube_r5", class_5606.method_32108().method_32101(18, 1).method_32098(-0.5F, -9.0F, -0.5F, 1.0F, 18.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -1.5F, 0.0F, 0.0F, -0.7854F, 0.0F));
        return class_5607.method_32110(modelData, 32, 32);
    }
}

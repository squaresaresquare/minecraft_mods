package net.kaupenjoe.tutorialmod.entity.custom;

import net.kaupenjoe.tutorialmod.entity.ModEntities;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5611;

public class TomahawkProjectileEntity extends class_1665 {
    private float rotation;
    public class_5611 groundedOffset;

    public TomahawkProjectileEntity(class_1299<? extends class_1665> entityType, class_1937 world) {
        super(entityType, world);
    }

    public TomahawkProjectileEntity(class_1937 world, class_1657 player) {
        super(ModEntities.TOMAHAWK, player, world, new class_1799(ModItems.TOMAHAWK), null);
    }

    @Override
    protected class_1799 method_57314() {
        return new class_1799(ModItems.TOMAHAWK);
    }

    public float getRenderingRotation() {
        rotation += 0.5f;
        if(rotation >= 360) {
            rotation = 0;
        }
        return rotation;
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        super.method_7454(entityHitResult);
        class_1297 entity = entityHitResult.method_17782();

        if (!this.method_73183().method_8608()) {
            entity.method_64397(((class_3218) this.method_73183()), this.method_48923().method_48811(this, this.method_24921()), 4);

            this.method_73183().method_8421(this, (byte)3);
            this.method_31472();
        }
    }

    @Override
    protected void method_24920(class_3965 result) {
        super.method_24920(result);

        if(result.method_17780() == class_2350.field_11035) {
            groundedOffset = new class_5611(215f,180f);
        }
        if(result.method_17780() == class_2350.field_11043) {
            groundedOffset = new class_5611(215f, 0f);
        }
        if(result.method_17780() == class_2350.field_11034) {
            groundedOffset = new class_5611(215f,-90f);
        }
        if(result.method_17780() == class_2350.field_11039) {
            groundedOffset = new class_5611(215f,90f);
        }

        if(result.method_17780() == class_2350.field_11033) {
            groundedOffset = new class_5611(115f,180f);
        }
        if(result.method_17780() == class_2350.field_11036) {
            groundedOffset = new class_5611(285f,180f);
        }
    }
}

package net.kaupenjoe.tutorialmod.entity.custom;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2945;
import net.minecraft.class_3218;

public class ChairEntity extends class_1297 {
    public ChairEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {

    }

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        return false;
    }

    @Override
    protected void method_5749(class_11368 view) {

    }

    @Override
    protected void method_5652(class_11372 view) {

    }
    
    @Override
    protected void method_5793(class_1297 passenger) {
        super.method_5793(passenger);
        if(!this.method_73183().method_8608()) {
            this.method_5768(((class_3218) this.method_73183()));
        }
    }
}

package net.kaupenjoe.tutorialmod.entity.client;

import net.kaupenjoe.tutorialmod.entity.custom.ChairEntity;
import net.minecraft.class_10017;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class ChairRenderer extends class_897<ChairEntity, class_10017> {
    public ChairRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public boolean shouldRender(ChairEntity entity, class_4604 frustum, double x, double y, double z) {
        return true;
    }

    @Override
    public class_10017 method_55269() {
        return new class_10017();
    }
}

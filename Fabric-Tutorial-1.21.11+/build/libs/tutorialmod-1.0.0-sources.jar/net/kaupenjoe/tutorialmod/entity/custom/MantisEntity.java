package net.kaupenjoe.tutorialmod.entity.custom;

import net.kaupenjoe.tutorialmod.entity.ModEntities;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1259;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_1341;
import net.minecraft.class_1347;
import net.minecraft.class_1353;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1429;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_7094;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class MantisEntity extends class_1429 {
    public final class_7094 idleAnimationState = new class_7094();
    private int idleAnimationTimeout = 0;

    private static final class_2940<Integer> DATA_ID_TYPE_VARIANT =
            class_2945.method_12791(MantisEntity.class, class_2943.field_13327);

    private final class_3213 bossBar = new class_3213(class_2561.method_43470("Our Menacing Mantis"),
            class_1259.class_1260.field_5785, class_1259.class_1261.field_5791);

    public MantisEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));

        this.field_6201.method_6277(1, new class_1341(this, 1.15D));
        this.field_6201.method_6277(2, new class_1391(this, 1.25D, class_1856.method_8091(ModItems.CAULIFLOWER), false));

        this.field_6201.method_6277(3, new class_1353(this, 1.1D));

        this.field_6201.method_6277(4, new class_1394(this, 1.0D));
        this.field_6201.method_6277(5, new class_1361(this, class_1657.class, 4.0F));
        this.field_6201.method_6277(6, new class_1376(this));
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 18)
                .method_26868(class_5134.field_23719, 0.35)
                .method_26868(class_5134.field_23721, 1)
                .method_26868(class_5134.field_23717, 20)
                .method_26868(class_5134.field_52450, 12);
    }

    private void setupAnimationStates() {
        if (this.idleAnimationTimeout <= 0) {
            this.idleAnimationTimeout = 40;
            this.idleAnimationState.method_41322(this.field_6012);
        } else {
            --this.idleAnimationTimeout;
        }
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_73183().method_8608()) {
            this.setupAnimationStates();
        }
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(ModItems.CAULIFLOWER);
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        MantisEntity baby = ModEntities.MANTIS.method_5883(world, class_3730.field_16466);
        MantisVariant variant = class_156.method_27173(MantisVariant.values(), this.field_5974);
        baby.setVariant(variant);
        return baby;
    }

    /* VARIANT */
    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(DATA_ID_TYPE_VARIANT, 0);
    }

    public MantisVariant getVariant() {
        return MantisVariant.byId(this.getTypeVariant() & 255);
    }

    private int getTypeVariant() {
        return this.field_6011.method_12789(DATA_ID_TYPE_VARIANT);
    }

    private void setVariant(MantisVariant variant) {
        this.field_6011.method_12778(DATA_ID_TYPE_VARIANT, variant.getId() & 255);
    }

    @Override
    public void method_5647(class_11372 view) {
        super.method_5647(view);
        view.method_71465("Variant", this.getTypeVariant());
    }

    @Override
    public void method_5651(class_11368 view) {
        super.method_5651(view);
        this.field_6011.method_12778(DATA_ID_TYPE_VARIANT, view.method_71424("Variant", 0));
    }

    @Override
    public class_1315 method_5943(class_5425 world, class_1266 difficulty, class_3730 spawnReason,
                                 @Nullable class_1315 entityData) {
        MantisVariant variant = class_156.method_27173(MantisVariant.values(), this.field_5974);
        setVariant(variant);
        return super.method_5943(world, difficulty, spawnReason, entityData);
    }

    /* SOUNDS */
    @Nullable
    @Override
    protected class_3414 method_5994() {
        return class_3417.field_15132;
    }

    @Nullable
    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_38369;
    }

    @Nullable
    @Override
    protected class_3414 method_6002() {
        return class_3417.field_15208;
    }

    /* BOSS BAR */
    @Override
    public void method_5837(class_3222 player) {
        super.method_5837(player);
        this.bossBar.method_14088(player);
    }

    @Override
    public void method_5742(class_3222 player) {
        super.method_5742(player);
        this.bossBar.method_14089(player);
    }

    @Override
    protected void method_5958(class_3218 world) {
        super.method_5958(world);
        this.bossBar.method_5408(this.method_6032() / this.method_6063());
    }
}

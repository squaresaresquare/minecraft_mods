package net.kaupenjoe.tutorialmod.entity.client;

import com.google.common.collect.Maps;
import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.entity.custom.MantisEntity;
import net.kaupenjoe.tutorialmod.entity.custom.MantisVariant;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import java.util.Map;

public class MantisRenderer extends class_927<MantisEntity, MantisRenderState, MantisModel> {
    private static final Map<MantisVariant, class_2960> LOCATION_BY_VARIANT =
            class_156.method_654(Maps.newEnumMap(MantisVariant.class), map -> {
                map.put(MantisVariant.DEFAULT,
                        class_2960.method_60655(TutorialMod.MOD_ID, "textures/entity/mantis/mantis.png"));
                map.put(MantisVariant.ORCHID,
                        class_2960.method_60655(TutorialMod.MOD_ID, "textures/entity/mantis/mantis_orchid.png"));
            });

    public MantisRenderer(class_5617.class_5618 context) {
        super(context, new MantisModel(context.method_32167(MantisModel.MANTIS)), 0.75f);
    }

    @Override
    public class_2960 getTexture(MantisRenderState state) {
        return LOCATION_BY_VARIANT.get(state.variant);
    }

    @Override
    public void render(MantisRenderState state, class_4587 matrixStack,
                       class_11659 orderedRenderCommandQueue, class_12075 cameraRenderState) {
        if(state.field_53457) {
            matrixStack.method_22905(0.5f, 0.5f, 0.5f);
        } else {
            matrixStack.method_22905(1f, 1f, 1f);
        }

        super.method_4054(state, matrixStack, orderedRenderCommandQueue, cameraRenderState);
    }

    @Override
    public MantisRenderState method_55269() {
        return new MantisRenderState();
    }

    @Override
    public void updateRenderState(MantisEntity livingEntity, MantisRenderState livingEntityRenderState, float f) {
        super.method_62355(livingEntity, livingEntityRenderState, f);
        livingEntityRenderState.idleAnimationState.method_61401(livingEntity.idleAnimationState);
        livingEntityRenderState.variant = livingEntity.getVariant();
    }
}

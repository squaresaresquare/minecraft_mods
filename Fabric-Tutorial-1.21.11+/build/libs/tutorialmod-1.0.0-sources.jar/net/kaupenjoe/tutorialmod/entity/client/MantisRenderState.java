package net.kaupenjoe.tutorialmod.entity.client;

import net.kaupenjoe.tutorialmod.entity.custom.MantisVariant;
import net.minecraft.class_10042;
import net.minecraft.class_7094;

public class MantisRenderState extends class_10042 {
    public final class_7094 idleAnimationState = new class_7094();
    public MantisVariant variant;
}

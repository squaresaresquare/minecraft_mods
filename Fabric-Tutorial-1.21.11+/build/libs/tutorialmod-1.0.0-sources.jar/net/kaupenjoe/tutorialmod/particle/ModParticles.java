package net.kaupenjoe.tutorialmod.particle;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.kaupenjoe.tutorialmod.TutorialMod;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModParticles {
    public static final class_2400 PINK_GARNET_PARTICLE =
            registerParticle("pink_garnet_particle", FabricParticleTypes.simple());

    private static class_2400 registerParticle(String name, class_2400 particleType) {
        return class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(TutorialMod.MOD_ID, name), particleType);
    }

    public static void registerParticles() {
        TutorialMod.LOGGER.info("Registering Particles for " + TutorialMod.MOD_ID);
    }
}

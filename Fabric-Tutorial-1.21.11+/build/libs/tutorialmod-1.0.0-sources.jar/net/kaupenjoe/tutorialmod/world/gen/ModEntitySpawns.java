package net.kaupenjoe.tutorialmod.world.gen;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.kaupenjoe.tutorialmod.entity.ModEntities;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_1429;
import net.minecraft.class_1972;
import net.minecraft.class_2902;
import net.minecraft.class_9169;

public class ModEntitySpawns {
    public static void addSpawns() {
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(class_1972.field_9451, class_1972.field_42720),
                class_1311.field_6294, ModEntities.MANTIS, 30, 1, 2);

        class_1317.method_20637(ModEntities.MANTIS, class_9169.field_48745,
                class_2902.class_2903.field_13203, class_1429::method_20663);
    }
}

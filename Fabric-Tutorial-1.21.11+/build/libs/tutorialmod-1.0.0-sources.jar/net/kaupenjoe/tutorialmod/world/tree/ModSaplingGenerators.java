package net.kaupenjoe.tutorialmod.world.tree;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.world.ModConfiguredFeatures;
import net.minecraft.class_8813;
import java.util.Optional;

public class ModSaplingGenerators {
    public static final class_8813 DRIFTWOOD = new class_8813(TutorialMod.MOD_ID + ":driftwood",
            Optional.empty(), Optional.of(ModConfiguredFeatures.DRIFTWOOD_KEY), Optional.empty());
}

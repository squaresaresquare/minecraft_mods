package net.kaupenjoe.tutorialmod.world.gen;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.kaupenjoe.tutorialmod.world.ModPlacedFeatures;
import net.minecraft.class_1972;
import net.minecraft.class_2893;

public class ModBushGeneration {
    public static void generateBushes() {
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(class_1972.field_9451, class_1972.field_9409),
                class_2893.class_2895.field_13178, ModPlacedFeatures.HONEY_BERRY_BUSH_PLACED_KEY);
    }
}

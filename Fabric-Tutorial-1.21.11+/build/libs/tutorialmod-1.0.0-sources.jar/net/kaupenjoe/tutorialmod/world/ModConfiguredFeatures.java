package net.kaupenjoe.tutorialmod.world;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3124;
import net.minecraft.class_3175;
import net.minecraft.class_3481;
import net.minecraft.class_3798;
import net.minecraft.class_3819;
import net.minecraft.class_3825;
import net.minecraft.class_3830;
import net.minecraft.class_4643;
import net.minecraft.class_4646;
import net.minecraft.class_4651;
import net.minecraft.class_5140;
import net.minecraft.class_5204;
import net.minecraft.class_5321;
import net.minecraft.class_6016;
import net.minecraft.class_6803;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import java.util.List;

public class ModConfiguredFeatures {
    public static final class_5321<class_2975<?, ?>> PINK_GARNET_ORE_KEY = registerKey("pink_garnet_ore");
    public static final class_5321<class_2975<?, ?>> NETHER_PINK_GARNET_ORE_KEY = registerKey("nether_pink_garnet_ore");
    public static final class_5321<class_2975<?, ?>> END_PINK_GARNET_ORE_KEY = registerKey("end_pink_garnet_ore");

    public static final class_5321<class_2975<?, ?>> DRIFTWOOD_KEY = registerKey("driftwood");

    public static final class_5321<class_2975<?, ?>> HONEY_BERRY_BUSH_KEY = registerKey("honey_berry_bush");

    public static void bootstrap(class_7891<class_2975<?, ?>> context) {
        class_3825 stoneReplaceables = new class_3798(class_3481.field_28992);
        class_3825 deepslateReplaceables = new class_3798(class_3481.field_28993);
        class_3825 netherReplaceables = new class_3798(class_3481.field_25807);
        class_3825 endReplaceables = new class_3819(class_2246.field_10471);

        List<class_3124.class_5876> overworldPinkGarnetOres =
                List.of(class_3124.method_33994(stoneReplaceables, ModBlocks.PINK_GARNET_ORE.method_9564()),
                        class_3124.method_33994(deepslateReplaceables, ModBlocks.PINK_GARNET_DEEPSLATE_ORE.method_9564()));
        List<class_3124.class_5876> netherPinkGarnetOres =
                List.of(class_3124.method_33994(netherReplaceables, ModBlocks.PINK_GARNET_NETHER_ORE.method_9564()));
        List<class_3124.class_5876> endPinkGarnetOres =
                List.of(class_3124.method_33994(endReplaceables, ModBlocks.PINK_GARNET_END_ORE.method_9564()));

        register(context, PINK_GARNET_ORE_KEY, class_3031.field_13517, new class_3124(overworldPinkGarnetOres, 12));
        register(context, NETHER_PINK_GARNET_ORE_KEY, class_3031.field_13517, new class_3124(netherPinkGarnetOres, 9));
        register(context, END_PINK_GARNET_ORE_KEY, class_3031.field_13517, new class_3124(endPinkGarnetOres, 9));

        register(context, DRIFTWOOD_KEY, class_3031.field_24134, new class_4643.class_4644(
                class_4651.method_38432(ModBlocks.DRIFTWOOD_LOG),
                new class_5140(5, 6, 3),

                class_4651.method_38432(ModBlocks.DRIFTWOOD_LEAVES),
                new class_4646(class_6016.method_34998(4), class_6016.method_34998(1), 3),

                new class_5204(1, 0, 2)).method_34346(class_4651.method_38432(class_2246.field_10340)).method_23445());

        register(context, HONEY_BERRY_BUSH_KEY, class_3031.field_21220,
                class_6803.method_39705(class_3031.field_13518,
                        new class_3175(class_4651.method_38433(ModBlocks.HONEY_BERRY_BUSH
                                .method_9564().method_11657(class_3830.field_17000, 3))),
                        List.of(class_2246.field_10219)));
    }

    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_60655(TutorialMod.MOD_ID, name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }
}

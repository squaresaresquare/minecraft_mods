package net.kaupenjoe.tutorialmod.world;

import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.block.ModBlocks;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_6792;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6817;
import net.minecraft.class_6819;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.gen.placementmodifier.*;

import java.util.List;

public class ModPlacedFeatures {
    public static final class_5321<class_6796> PINK_GARNET_ORE_PLACED_KEY = registerKey("pink_garnet_ore_placed");
    public static final class_5321<class_6796> NETHER_PINK_GARNET_ORE_PLACED_KEY = registerKey("nether_pink_garnet_ore_placed");
    public static final class_5321<class_6796> END_PINK_GARNET_ORE_PLACED_KEY = registerKey("end_pink_garnet_ore_placed");

    public static final class_5321<class_6796> DRIFTWOOD_PLACED_KEY = registerKey("driftwood_placed");

    public static final class_5321<class_6796> HONEY_BERRY_BUSH_PLACED_KEY = registerKey("honey_berry_bush_placed");

    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatures = context.method_46799(class_7924.field_41239);

        register(context, PINK_GARNET_ORE_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.PINK_GARNET_ORE_KEY),
                ModOrePlacement.modifiersWithCount(14,
                        class_6795.method_39637(class_5843.method_33841(-80), class_5843.method_33841(80))));
        register(context, NETHER_PINK_GARNET_ORE_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.NETHER_PINK_GARNET_ORE_KEY),
                ModOrePlacement.modifiersWithCount(14,
                        class_6795.method_39634(class_5843.method_33841(-80), class_5843.method_33841(80))));
        register(context, END_PINK_GARNET_ORE_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.END_PINK_GARNET_ORE_KEY),
                ModOrePlacement.modifiersWithCount(14,
                        class_6795.method_39634(class_5843.method_33841(-80), class_5843.method_33841(80))));

        register(context, DRIFTWOOD_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.DRIFTWOOD_KEY),
                class_6819.method_39741(
                        class_6817.method_39736(2, 0.1f, 2), ModBlocks.DRIFTWOOD_SAPLING));

        register(context, HONEY_BERRY_BUSH_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.HONEY_BERRY_BUSH_KEY),
                class_6799.method_39659(32), class_5450.method_39639(), class_6817.field_36078, class_6792.method_39614());
    }

    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_60655(TutorialMod.MOD_ID, name));
    }

    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                                                                   class_6880<class_2975<?, ?>> configuration,
                                                                                   class_6797... modifiers) {
        register(context, key, configuration, List.of(modifiers));
    }
}

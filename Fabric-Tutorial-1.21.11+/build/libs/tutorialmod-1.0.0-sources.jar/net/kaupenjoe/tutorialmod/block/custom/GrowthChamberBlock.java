package net.kaupenjoe.tutorialmod.block.custom;

import com.mojang.serialization.MapCodec;
import net.kaupenjoe.tutorialmod.block.entity.ModBlockEntities;
import net.kaupenjoe.tutorialmod.block.entity.custom.GrowthChamberBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class GrowthChamberBlock extends class_2237 implements class_2343 {
    public static final MapCodec<GrowthChamberBlock> CODEC = GrowthChamberBlock.method_54094(GrowthChamberBlock::new);

    public GrowthChamberBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new GrowthChamberBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos,
                                         class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.method_8608()) {
            class_3908 screenHandlerFactory = ((GrowthChamberBlockEntity) world.method_8321(pos));
            if (screenHandlerFactory != null) {
                player.method_17355(screenHandlerFactory);
            }
        }
        return class_1269.field_5812;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if(world.method_8608()) {
            return null;
        }

        return method_31618(type, ModBlockEntities.GROWTH_CHAMBER_BE,
                (world1, pos, state1, blockEntity) -> blockEntity.tick(world1, pos, state1));
    }
}

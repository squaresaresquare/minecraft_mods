package net.kaupenjoe.tutorialmod.block;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.kaupenjoe.tutorialmod.TutorialMod;
import net.kaupenjoe.tutorialmod.block.custom.*;
import net.kaupenjoe.tutorialmod.sound.ModSounds;
import net.kaupenjoe.tutorialmod.world.tree.ModSaplingGenerators;
import net.minecraft.block.*;
import net.minecraft.class_10717;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_2431;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4719;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_6019;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8177;
import java.util.function.Function;

public class ModBlocks {
    public static final class_2248 PINK_GARNET_BLOCK = registerBlock("pink_garnet_block",
            properties -> new class_2248(properties.method_9632(4f)
                    .method_29292().method_9626(class_2498.field_27197)));
    public static final class_2248 RAW_PINK_GARNET_BLOCK = registerBlock("raw_pink_garnet_block",
            properties -> new class_2248(properties.method_9632(3f)
                    .method_29292()));

    public static final class_2248 PINK_GARNET_ORE = registerBlock("pink_garnet_ore",
            properties -> new class_2431(class_6019.method_35017(2, 5),
                    properties.method_9632(3f).method_29292()));
    public static final class_2248 PINK_GARNET_DEEPSLATE_ORE = registerBlock("pink_garnet_deepslate_ore",
            properties -> new class_2431(class_6019.method_35017(3, 6),
                    properties.method_9632(4f).method_29292().method_9626(class_2498.field_29033)));

    public static final class_2248 PINK_GARNET_END_ORE = registerBlock("pink_garnet_end_ore",
            properties -> new class_2431(class_6019.method_35017(4, 8),
                    properties.method_9632(7f).method_29292()));
    public static final class_2248 PINK_GARNET_NETHER_ORE = registerBlock("pink_garnet_nether_ore",
            properties -> new class_2431(class_6019.method_35017(1, 5),
                    properties.method_9632(3f).method_29292()));

    public static final class_2248 MAGIC_BLOCK = registerBlock("magic_block",
            properties -> new MagicBlock(properties.method_9632(1f).method_29292().method_9626(ModSounds.MAGIC_BLOCK_SOUNDS)));

    public static final class_2248 PINK_GARNET_STAIRS = registerBlock("pink_garnet_stairs",
            properties -> new class_2510(ModBlocks.PINK_GARNET_BLOCK.method_9564(),
                    properties.method_9632(2f).method_29292()));
    public static final class_2248 PINK_GARNET_SLAB = registerBlock("pink_garnet_slab",
            properties -> new class_2482(properties.method_9632(2f).method_29292()));

    public static final class_2248 PINK_GARNET_BUTTON = registerBlock("pink_garnet_button",
            properties -> new class_2269(class_8177.field_42819, 2, properties.method_9632(2f).method_29292().method_9634()));
    public static final class_2248 PINK_GARNET_PRESSURE_PLATE = registerBlock("pink_garnet_pressure_plate",
            properties -> new class_2440(class_8177.field_42819, properties.method_9632(2f).method_29292()));

    public static final class_2248 PINK_GARNET_FENCE = registerBlock("pink_garnet_fence",
            properties -> new class_2354(properties.method_9632(2f).method_29292()));
    public static final class_2248 PINK_GARNET_FENCE_GATE = registerBlock("pink_garnet_fence_gate",
            properties -> new class_2349(class_4719.field_21679, properties.method_9632(2f).method_29292()));
    public static final class_2248 PINK_GARNET_WALL = registerBlock("pink_garnet_wall",
            properties -> new class_2544(properties.method_9632(2f).method_29292()));

    public static final class_2248 PINK_GARNET_DOOR = registerBlock("pink_garnet_door",
            properties -> new class_2323(class_8177.field_42819, properties.method_9632(2f).method_29292().method_22488()));
    public static final class_2248 PINK_GARNET_TRAPDOOR = registerBlock("pink_garnet_trapdoor",
            properties -> new class_2533(class_8177.field_42819, properties.method_9632(2f).method_29292().method_22488()));

    public static final class_2248 PINK_GARNET_LAMP = registerBlock("pink_garnet_lamp",
            properties -> new PinkGarnetLampBlock(properties
                    .method_9632(1f).method_29292().method_9631(state -> state.method_11654(PinkGarnetLampBlock.CLICKED) ? 15 : 0)));

    public static final class_2248 CAULIFLOWER_CROP = registerBlockWithoutBlockItem("cauliflower_crop",
            properties -> new CauliflowerCropBlock(properties.method_9634()
                    .method_9640().method_9618().method_9626(class_2498.field_17580)
                    .method_50012(class_3619.field_15971)));
    public static final class_2248 HONEY_BERRY_BUSH = registerBlockWithoutBlockItem("honey_berry_bush",
            properties -> new HoneyBerryBushBlock(properties.method_31710(class_3620.field_16004).method_9640()
                    .method_9634().method_9626(class_2498.field_17579).method_50012(class_3619.field_15971)));


    public static final class_2248 DRIFTWOOD_LOG = registerBlock("driftwood_log",
            properties -> new class_2465(properties
                    .method_51368(class_2766.field_12651)
                    .method_9632(2.0F).method_9626(class_2498.field_11547).method_50013()));
    public static final class_2248 DRIFTWOOD_WOOD = registerBlock("driftwood_wood",
            properties -> new class_2465(properties
                    .method_51368(class_2766.field_12651)
                    .method_9632(2.0F).method_9626(class_2498.field_11547).method_50013()));
    public static final class_2248 STRIPPED_DRIFTWOOD_LOG = registerBlock("stripped_driftwood_log",
            properties -> new class_2465(properties
                    .method_51368(class_2766.field_12651)
                    .method_9632(2.0F).method_9626(class_2498.field_11547).method_50013()));
    public static final class_2248 STRIPPED_DRIFTWOOD_WOOD = registerBlock("stripped_driftwood_wood",
            properties -> new class_2465(properties
                    .method_51368(class_2766.field_12651)
                    .method_9632(2.0F).method_9626(class_2498.field_11547).method_50013()));

    public static final class_2248 DRIFTWOOD_PLANKS = registerBlock("driftwood_planks",
            properties -> new class_2248(properties.method_9632(3f)));
    public static final class_2248 DRIFTWOOD_LEAVES = registerBlock("driftwood_leaves",
            properties -> new class_10717(0.02f, class_2398.field_43379, properties
                    .method_31710(class_3620.field_16004).method_9632(0.2F).method_9640()
                    .method_9626(class_2498.field_28702).method_22488()
                    .method_26235(class_2246::method_26126).method_26243(class_2246::method_26122)
                    .method_26245(class_2246::method_26122).method_50013().method_50012(class_3619.field_15971)
                    .method_26236(class_2246::method_26122)));

    public static final class_2248 DRIFTWOOD_SAPLING = registerBlock("driftwood_sapling",
            properties -> new ModSaplingBlock(ModSaplingGenerators.DRIFTWOOD, properties.method_31710(class_3620.field_16004)
                    .method_9634().method_9640().method_9618()
                    .method_9626(class_2498.field_11535).method_50012(class_3619.field_15971), class_2246.field_10340));

    public static final class_2248 CHAIR = registerBlock("chair",
            properties -> new ChairBlock(properties.method_22488()));

    public static final class_2248 PEDESTAL = registerBlock("pedestal",
            properties -> new PedestalBlock(properties.method_22488()));

    public static final class_2248 GROWTH_CHAMBER = registerBlock("growth_chamber", GrowthChamberBlock::new);



    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> function) {
        class_2248 toRegister = function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(TutorialMod.MOD_ID, name))));
        registerBlockItem(name, toRegister);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TutorialMod.MOD_ID, name), toRegister);
    }

    private static class_2248 registerBlockWithoutBlockItem(String name, Function<class_4970.class_2251, class_2248> function) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TutorialMod.MOD_ID, name),
                function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(TutorialMod.MOD_ID, name)))));
    }

    private static void registerBlockItem(String name, class_2248 block) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TutorialMod.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(TutorialMod.MOD_ID, name)))));
    }

    public static void registerModBlocks() {
        TutorialMod.LOGGER.info("Registering Mod Blocks for " + TutorialMod.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            entries.method_45421(ModBlocks.PINK_GARNET_BLOCK);
            entries.method_45421(ModBlocks.RAW_PINK_GARNET_BLOCK);
        });
    }
}

package net.kaupenjoe.tutorialmod.block.entity.renderer;

import net.kaupenjoe.tutorialmod.block.entity.custom.PedestalBlockEntity;
import net.minecraft.class_10442;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import org.jetbrains.annotations.Nullable;

public class PedestalBlockEntityRenderer implements class_827<PedestalBlockEntity, PedestalBlockEntityRenderState> {
    private final class_10442 itemModelManager;

    public PedestalBlockEntityRenderer(class_5614.class_5615 context) {
        itemModelManager = context.comp_4536();
    }

    @Override
    public PedestalBlockEntityRenderState method_74335() {
        return new PedestalBlockEntityRenderState();
    }

    @Override
    public void updateRenderState(PedestalBlockEntity blockEntity, PedestalBlockEntityRenderState state, float tickProgress,
                                  class_243 cameraPos, @Nullable class_11683.class_11792 crumblingOverlay) {
        class_827.super.method_74331(blockEntity, state, tickProgress, cameraPos, crumblingOverlay);

        state.lightPosition = blockEntity.method_11016();
        state.blockEntityWorld = blockEntity.method_10997();
        state.rotation = blockEntity.getRenderingRotation();

        itemModelManager.method_65598(state.itemRenderState,
                blockEntity.method_5438(0), class_811.field_4319, blockEntity.method_10997(), null, 0);
    }

    @Override
    public void render(PedestalBlockEntityRenderState state, class_4587 matrices, class_11659 queue, class_12075 cameraState) {
        matrices.method_22903();

        matrices.method_46416(0.5f, 1.15f, 0.5f);
        matrices.method_22905(0.5f, 0.5f, 0.5f);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(state.rotation));

        state.itemRenderState.method_65604(matrices, queue, getLightLevel(state.blockEntityWorld, state.field_62673), class_4608.field_21444, 0);

        matrices.method_22909();
    }

    private int getLightLevel(class_1937 world, class_2338 pos) {
        int bLight = world.method_8314(class_1944.field_9282, pos);
        int sLight = world.method_8314(class_1944.field_9284, pos);
        return class_765.method_23687(bLight, sLight);
    }
}

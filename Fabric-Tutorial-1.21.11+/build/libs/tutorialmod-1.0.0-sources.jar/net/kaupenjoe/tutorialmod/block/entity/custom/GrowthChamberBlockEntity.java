package net.kaupenjoe.tutorialmod.block.entity.custom;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.kaupenjoe.tutorialmod.block.entity.ImplementedInventory;
import net.kaupenjoe.tutorialmod.block.entity.ModBlockEntities;
import net.kaupenjoe.tutorialmod.item.ModItems;
import net.kaupenjoe.tutorialmod.recipe.GrowthChamberRecipe;
import net.kaupenjoe.tutorialmod.recipe.GrowthChamberRecipeInput;
import net.kaupenjoe.tutorialmod.recipe.ModRecipes;
import net.kaupenjoe.tutorialmod.screen.custom.GrowthChamberScreenHandler;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1264;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class GrowthChamberBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, ImplementedInventory {
    private final class_2371<class_1799> inventory = class_2371.method_10213(2, class_1799.field_8037);

    private static final int INPUT_SLOT = 0;
    private static final int OUTPUT_SLOT = 1;

    protected final class_3913 propertyDelegate;
    private int progress = 0;
    private int maxProgress = 72;

    public GrowthChamberBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.GROWTH_CHAMBER_BE, pos, state);
        this.propertyDelegate = new class_3913() {
            @Override
            public int method_17390(int index) {
                return switch (index) {
                    case 0 -> GrowthChamberBlockEntity.this.progress;
                    case 1 -> GrowthChamberBlockEntity.this.maxProgress;
                    default -> 0;
                };
            }

            @Override
            public void method_17391(int index, int value) {
                switch (index) {
                    case 0: GrowthChamberBlockEntity.this.progress = value;
                    case 1: GrowthChamberBlockEntity.this.maxProgress = value;
                }
            }

            @Override
            public int method_17389() {
                return 2;
            }
        };
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return this.field_11867;
    }

    @Override
    public class_2371<class_1799> getItems() {
        return inventory;
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471("block.tutorialmod.growth_chamber");
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new GrowthChamberScreenHandler(syncId, playerInventory, this, this.propertyDelegate);
    }

    @Override
    public void method_66473(class_2338 pos, class_2680 oldState) {
        class_1264.method_5451(field_11863, pos, (this));
        super.method_66473(pos, oldState);
    }

    @Override
    protected void method_11007(class_11372 view) {
        super.method_11007(view);
        class_1262.method_5426(view, inventory);
        view.method_71465("growth_chamber.progress", progress);
        view.method_71465("growth_chamber.max_progress", maxProgress);
    }

    @Override
    protected void method_11014(class_11368 view) {
        class_1262.method_5429(view, inventory);
        progress = view.method_71424("growth_chamber.progress", 0);
        maxProgress = view.method_71424("growth_chamber.max_progress", 0);
        super.method_11014(view);
    }

    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        if(hasRecipe()) {
            increaseCraftingProgress();
            method_31663(world, pos, state);

            if(hasCraftingFinished()) {
                craftItem();
                resetProgress();
            }
        } else {
            resetProgress();
        }
    }

    private void resetProgress() {
        this.progress = 0;
        this.maxProgress = 72;
    }

    private void craftItem() {
        Optional<class_8786<GrowthChamberRecipe>> recipe = getCurrentRecipe();

        class_1799 output = recipe.get().comp_1933().output();
        this.method_5434(INPUT_SLOT, 1);
        this.method_5447(OUTPUT_SLOT, new class_1799(output.method_7909(),
                this.method_5438(OUTPUT_SLOT).method_7947() + output.method_7947()));
    }

    private boolean hasCraftingFinished() {
        return this.progress >= this.maxProgress;
    }

    private void increaseCraftingProgress() {
        this.progress++;
    }

    private boolean hasRecipe() {
        Optional<class_8786<GrowthChamberRecipe>> recipe = getCurrentRecipe();
        if(recipe.isEmpty()) {
            return false;
        }

        class_1799 output = recipe.get().comp_1933().output();
        return canInsertAmountIntoOutputSlot(output.method_7947()) && canInsertItemIntoOutputSlot(output);
    }

    private Optional<class_8786<GrowthChamberRecipe>> getCurrentRecipe() {
        return ((class_3218) this.method_10997()).method_64577()
                .method_8132(ModRecipes.GROWTH_CHAMBER_TYPE, new GrowthChamberRecipeInput(inventory.get(INPUT_SLOT)), this.method_10997());
    }

    private boolean canInsertItemIntoOutputSlot(class_1799 output) {
        return this.method_5438(OUTPUT_SLOT).method_7960() || this.method_5438(OUTPUT_SLOT).method_7909() == output.method_7909();
    }

    private boolean canInsertAmountIntoOutputSlot(int count) {
        int maxCount = this.method_5438(OUTPUT_SLOT).method_7960() ? 64 : this.method_5438(OUTPUT_SLOT).method_7914();
        int currentCount = this.method_5438(OUTPUT_SLOT).method_7947();

        return maxCount >= currentCount + count;
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registryLookup) {
        return method_38244(registryLookup);
    }
}

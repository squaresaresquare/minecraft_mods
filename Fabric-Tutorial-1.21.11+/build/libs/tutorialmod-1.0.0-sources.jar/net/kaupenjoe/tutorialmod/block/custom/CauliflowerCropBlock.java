package net.kaupenjoe.tutorialmod.block.custom;

import net.kaupenjoe.tutorialmod.item.ModItems;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;

public class CauliflowerCropBlock extends class_2302 {
    public static final int MAX_AGE = 6;
    public static final class_2758 AGE = class_2758.method_11867("age", 0, 6);

    public CauliflowerCropBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected class_1935 method_9832() {
        return ModItems.CAULIFLOWER_SEEDS;
    }

    @Override
    public class_2758 method_9824() {
        return field_10835;
    }

    @Override
    public int method_9827() {
        return field_31079;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_10835);
    }
}

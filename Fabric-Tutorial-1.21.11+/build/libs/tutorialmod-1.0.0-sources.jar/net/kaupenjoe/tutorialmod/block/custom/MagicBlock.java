package net.kaupenjoe.tutorialmod.block.custom;

import net.kaupenjoe.tutorialmod.particle.ModParticles;
import net.kaupenjoe.tutorialmod.util.ModTags;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import java.util.List;

public class MagicBlock extends class_2248 {
    public MagicBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player,
                                 class_3965 hit) {
        world.method_8406(ModParticles.PINK_GARNET_PARTICLE, pos.method_10263() + 0.5, pos.method_10264() + 1,
                pos.method_10260() + 0.5, 0, 1, 0);

        world.method_8396(player, pos, class_3417.field_26980, class_3419.field_15245, 1f, 1f);
        return class_1269.field_5812;
    }

    @Override
    public void method_9591(class_1937 world, class_2338 pos, class_2680 state, class_1297 entity) {
        if(entity instanceof class_1542 itemEntity) {
            if(isValidItem(itemEntity.method_6983())) {
                itemEntity.method_6979(new class_1799(class_1802.field_8477, itemEntity.method_6983().method_7947()));
            }
        }

        super.method_9591(world, pos, state, entity);
    }

    private boolean isValidItem(class_1799 stack) {
        return stack.method_31573(ModTags.Items.TRANSFORMABLE_ITEMS);
    }
}

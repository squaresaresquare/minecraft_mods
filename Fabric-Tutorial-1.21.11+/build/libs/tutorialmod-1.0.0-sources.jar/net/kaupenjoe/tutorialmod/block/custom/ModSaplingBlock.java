package net.kaupenjoe.tutorialmod.block.custom;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2473;
import net.minecraft.class_2680;
import net.minecraft.class_8813;

public class ModSaplingBlock extends class_2473 {
    private final class_2248 blockToPlaceOn;

    public ModSaplingBlock(class_8813 generator, class_2251 settings, class_2248 block) {
        super(generator, settings);
        this.blockToPlaceOn = block;
    }

    @Override
    protected boolean method_9695(class_2680 floor, class_1922 world, class_2338 pos) {
        return floor.method_27852(this.blockToPlaceOn);
    }
}

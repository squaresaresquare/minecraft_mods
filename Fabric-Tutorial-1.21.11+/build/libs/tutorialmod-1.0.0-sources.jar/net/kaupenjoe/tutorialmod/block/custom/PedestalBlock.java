package net.kaupenjoe.tutorialmod.block.custom;

import com.mojang.serialization.MapCodec;
import net.kaupenjoe.tutorialmod.block.entity.custom.PedestalBlockEntity;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

public class PedestalBlock extends class_2237 implements class_2343 {
    private static final class_265 SHAPE =
            class_2248.method_9541(2, 0, 2, 14, 13, 14);
    public static final MapCodec<PedestalBlock> CODEC = PedestalBlock.method_54094(PedestalBlock::new);

    public PedestalBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PedestalBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos,
                                         class_1657 player, class_1268 hand, class_3965 hit) {
        if(world.method_8321(pos) instanceof PedestalBlockEntity pedestalBlockEntity) {
            if(pedestalBlockEntity.method_5442() && !stack.method_7960()) {
                pedestalBlockEntity.method_5447(0, stack.method_46651(1));
                world.method_8396(player, pos, class_3417.field_15197, class_3419.field_15245, 1f, 2f);
                stack.method_7934(1);

                pedestalBlockEntity.method_5431();
                world.method_8413(pos, state, state, 0);
            } else if(stack.method_7960() && !player.method_5715()) {
                class_1799 stackOnPedestal = pedestalBlockEntity.method_5438(0);
                player.method_6122(class_1268.field_5808, stackOnPedestal);
                world.method_8396(player, pos, class_3417.field_15197, class_3419.field_15245, 1f, 1f);
                pedestalBlockEntity.method_5448();

                pedestalBlockEntity.method_5431();
                world.method_8413(pos, state, state, 0);
            } else if(player.method_5715() && !world.method_8608()) {
                player.method_17355(pedestalBlockEntity);
            }
        }

        return class_1269.field_5812;
    }
}

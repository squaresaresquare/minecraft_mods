package org.seanpaulhumphrey.architecture.particle;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.seanpaulhumphrey.architecture.Architecture;

public class ModParticles {
    private static class_2400 registerParticle(String name, class_2400 particleType) {
        return class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(Architecture.MOD_ID, name), particleType);
    }

    public static void registerParticles() {
        Architecture.LOGGER.info("Registering Particles for " + Architecture.MOD_ID);
    }
}

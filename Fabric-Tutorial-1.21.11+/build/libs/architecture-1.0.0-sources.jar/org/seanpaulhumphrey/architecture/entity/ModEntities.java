package org.seanpaulhumphrey.architecture.entity;

import org.seanpaulhumphrey.architecture.Architecture;

public class ModEntities {
    public static void registerModEntities() {
        Architecture.LOGGER.info("Registering Mod Entities for " + Architecture.MOD_ID);
    }
}

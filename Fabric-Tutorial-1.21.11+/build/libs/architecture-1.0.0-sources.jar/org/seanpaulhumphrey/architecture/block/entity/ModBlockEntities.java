package org.seanpaulhumphrey.architecture.block.entity;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.seanpaulhumphrey.architecture.Architecture;
import org.seanpaulhumphrey.architecture.block.ModBlocks;
import org.seanpaulhumphrey.architecture.block.entity.custom.QuartzPillarEntity;

public class ModBlockEntities {
    public static final class_2591<QuartzPillarEntity> PILLAR_BE =
            class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(Architecture.MOD_ID, "pillar_be"),
                    FabricBlockEntityTypeBuilder.create(QuartzPillarEntity::new, ModBlocks.QUARTZ_PILLAR).build(null));
    public static void registerBlockEntities() {
        Architecture.LOGGER.info("Registering Block Entities for " + Architecture.MOD_ID);
    }
}

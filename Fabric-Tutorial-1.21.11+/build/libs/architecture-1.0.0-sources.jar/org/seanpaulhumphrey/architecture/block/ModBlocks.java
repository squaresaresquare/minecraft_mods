package org.seanpaulhumphrey.architecture.block;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import org.seanpaulhumphrey.architecture.Architecture;
import org.seanpaulhumphrey.architecture.block.custom.*;
import org.seanpaulhumphrey.architecture.block.custom.*;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.Function;

public class ModBlocks {
    public static final class_2248 QUARTZ_PILLAR = registerBlock("quartz_pillar",
            properties -> new QuartzPillar(properties.method_22488()));

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> function) {
        class_2248 toRegister = function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Architecture.MOD_ID, name))));
        registerBlockItem(name, toRegister);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Architecture.MOD_ID, name), toRegister);
    }

    private static class_2248 registerBlockWithoutBlockItem(String name, Function<class_4970.class_2251, class_2248> function) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(Architecture.MOD_ID, name),
                function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(Architecture.MOD_ID, name)))));
    }

    private static void registerBlockItem(String name, class_2248 block) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Architecture.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Architecture.MOD_ID, name)))));
    }

    public static void registerModBlocks() {
        Architecture.LOGGER.info("Registering Mod Blocks for " + Architecture.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            entries.method_45421(ModBlocks.QUARTZ_PILLAR);
        });
    }
}

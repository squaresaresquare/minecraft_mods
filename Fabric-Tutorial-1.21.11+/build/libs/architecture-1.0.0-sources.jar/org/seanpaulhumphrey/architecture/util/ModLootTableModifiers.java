package org.seanpaulhumphrey.architecture.util;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import org.seanpaulhumphrey.architecture.item.ModItems;

public class ModLootTableModifiers {}

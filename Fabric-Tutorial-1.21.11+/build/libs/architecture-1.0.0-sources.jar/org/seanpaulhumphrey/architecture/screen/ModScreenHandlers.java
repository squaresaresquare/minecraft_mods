package org.seanpaulhumphrey.architecture.screen;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;
import org.seanpaulhumphrey.architecture.Architecture;
import org.seanpaulhumphrey.architecture.screen.custom.PillarScreenHandler;

public class ModScreenHandlers {
    public static final class_3917<PillarScreenHandler> PILLAR_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(Architecture.MOD_ID, "pillar_screen_handler"),
                    new ExtendedScreenHandlerType<>(PillarScreenHandler::new, class_2338.field_48404));

    public static void registerScreenHandlers() {
        Architecture.LOGGER.info("Registering Screen Handlers for " + Architecture.MOD_ID);
    }
}

package org.seanpaulhumphrey.architecture.recipe;

import org.seanpaulhumphrey.architecture.Architecture;

public class ModRecipes {
    public static void registerRecipes() {
        Architecture.LOGGER.info("Registering Custom Recipes for " + Architecture.MOD_ID);
    }
}

package org.seanpaulhumphrey.architecture.sound;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;
import org.seanpaulhumphrey.architecture.Architecture;

public class ModSounds {
    private static class_3414 registerSoundEvent(String name) {
        class_2960 id = class_2960.method_60655(Architecture.MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static void registerSounds() {
        Architecture.LOGGER.info("Registering Mod Sounds for " + Architecture.MOD_ID);
    }
}

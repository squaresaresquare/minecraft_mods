package org.seanpaulhumphrey.architecture;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3929;
import net.minecraft.class_5616;
import org.seanpaulhumphrey.architecture.block.entity.ModBlockEntities;
import org.seanpaulhumphrey.architecture.block.entity.renderer.QuartzPillarEntityRenderer;
import org.seanpaulhumphrey.architecture.screen.ModScreenHandlers;
import org.seanpaulhumphrey.architecture.screen.custom.PillarScreen;

public class ArchitectureModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_5616.method_32144(ModBlockEntities.PILLAR_BE, QuartzPillarEntityRenderer::new);
        class_3929.method_17542(ModScreenHandlers.PILLAR_SCREEN_HANDLER, PillarScreen::new);
    }
}

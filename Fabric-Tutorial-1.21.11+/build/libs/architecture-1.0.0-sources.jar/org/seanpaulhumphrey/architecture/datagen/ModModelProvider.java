package org.seanpaulhumphrey.architecture.datagen;

import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import org.seanpaulhumphrey.architecture.block.ModBlocks;
import org.seanpaulhumphrey.architecture.component.ModDataComponentTypes;
import org.seanpaulhumphrey.architecture.item.ModItems;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.client.data.*;
import java.util.Optional;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        class_4910.class_4912 pinkGarnetPool = blockStateModelGenerator.method_25650(ModBlocks.QUARTZ_PILLAR);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {

    }
}

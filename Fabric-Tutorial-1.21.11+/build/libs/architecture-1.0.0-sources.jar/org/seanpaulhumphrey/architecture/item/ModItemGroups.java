package org.seanpaulhumphrey.architecture.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import org.seanpaulhumphrey.architecture.Architecture;
import org.seanpaulhumphrey.architecture.block.ModBlocks;

public class ModItemGroups {
    public static void registerItemGroups() {
        Architecture.LOGGER.info("Registering Item Groups for " + Architecture.MOD_ID);
    }
}

package org.seanpaulhumphrey.architecture.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import org.seanpaulhumphrey.architecture.Architecture;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.item.*;
import java.util.function.Function;

public class ModItems {
    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> function) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(Architecture.MOD_ID, name),
                function.apply(new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Architecture.MOD_ID, name)))));
    }
    public static void registerModItems() {
        Architecture.LOGGER.info("Registering Mod Items for " + Architecture.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> {
        });
    }
}
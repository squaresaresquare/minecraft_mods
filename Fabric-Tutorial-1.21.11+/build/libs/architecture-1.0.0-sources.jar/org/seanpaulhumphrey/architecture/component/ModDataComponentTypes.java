package org.seanpaulhumphrey.architecture.component;

import org.seanpaulhumphrey.architecture.Architecture;
import java.util.function.UnaryOperator;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class ModDataComponentTypes {
    public static final class_9331<class_2338> COORDINATES =
            register("coordinates", builder -> builder.method_57881(class_2338.field_25064));


    private static <T>class_9331<T> register(String name, UnaryOperator<class_9331.class_9332<T>> builderOperator) {
        return class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(Architecture.MOD_ID, name),
                builderOperator.apply(class_9331.method_57873()).method_57880());
    }

    public static void registerDataComponentTypes() {
        Architecture.LOGGER.info("Registering Data Component Types for " + Architecture.MOD_ID);
    }
}
